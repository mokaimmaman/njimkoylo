// Vercel serverless entry – imports the Express app
const app = require('../backend/src/index.js');
module.exports = app;
