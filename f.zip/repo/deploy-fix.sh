#!/bin/bash

# ============================================
# Fiad Shop – Database Fix + Redeploy Script
# Run from: ~/fiadshop
# ============================================

set -e  # কোনো কমান্ড ফেল করলে থেমে যাবে

echo "🚀 Starting database fix & redeploy..."

# -------------------------------
# 1. Vercel Env Update (Production)
# -------------------------------
echo "📦 Updating DATABASE_URL in Vercel (Production)..."
vercel env rm DATABASE_URL production
vercel env add DATABASE_URL production <<< 'postgresql://postgres.tqnnqgqcaddjgxoxrbny:Poi098)(%2B%3E%3C%5C@aws-0-ap-southeast-1.pooler.supabase.com:6543/postgres?pgbouncer=true&sslmode=require'

# -------------------------------
# 2. Update local .env (backend)
# -------------------------------
echo "📝 Updating backend/.env..."
cat > backend/.env << 'EOF'
DATABASE_URL="postgresql://postgres.tqnnqgqcaddjgxoxrbny:Poi098)(%2B%3E%3C%5C@aws-0-ap-southeast-1.pooler.supabase.com:6543/postgres?pgbouncer=true&sslmode=require"
EOF

# -------------------------------
# 3. Prisma Generate (backend)
# -------------------------------
echo "⚙️ Running prisma generate..."
cd backend
npx prisma generate
cd ..

# -------------------------------
# 4. Deploy to Vercel (Production)
# -------------------------------
echo "🚀 Deploying to Vercel (Production)..."
vercel --prod

echo ""
echo "✅ All done! Check your deployment at:"
echo "   https://fiadshop-xxxx.vercel.app (your Vercel URL)"
echo ""
echo "📌 Test: /api/health should return {'ok':true}"
