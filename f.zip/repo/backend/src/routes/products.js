// Public product APIs (list, detail, search). Admin CRUD lives in admin.js.

const express = require('express');
const prisma = require('../lib/prisma');
const asyncHandler = require('../lib/asyncHandler');
const { requireAuth } = require('../middleware/auth');
const { z } = require('zod');

const router = express.Router();

router.get('/', asyncHandler(async (req, res) => {
  const { category, q, sort, limit = 24, offset = 0 } = req.query;
  const where = { isActive: true };
  if (category && category !== 'all') where.category = category;
  if (q) {
    where.OR = [
      { name: { contains: q, mode: 'insensitive' } },
      { description: { contains: q, mode: 'insensitive' } },
    ];
  }
  const orderBy =
    sort === 'price-asc'  ? { basePrice: 'asc' } :
    sort === 'price-desc' ? { basePrice: 'desc' } :
    sort === 'newest'     ? { createdAt: 'desc' } :
                            { createdAt: 'desc' };

  const [items, total] = await Promise.all([
    prisma.product.findMany({
      where, orderBy, take: Math.min(Number(limit), 100), skip: Number(offset),
      include: { variants: true },
    }),
    prisma.product.count({ where }),
  ]);
  res.json({ items, total, limit: Number(limit), offset: Number(offset) });
}));

router.get('/:id', asyncHandler(async (req, res) => {
  const p = await prisma.product.findUnique({
    where: { id: req.params.id },
    include: {
      variants: true,
      packageItems: { include: { childProduct: true } },
    },
  });
  if (!p || !p.isActive) return res.status(404).json({ error: 'Product not found' });
  res.json({ product: p });
}));

router.get('/by-sku/:sku', asyncHandler(async (req, res) => {
  const p = await prisma.product.findUnique({
    where: { sku: req.params.sku },
    include: { variants: true },
  });
  if (!p || !p.isActive) return res.status(404).json({ error: 'Product not found' });
  res.json({ product: p });
}));

// Reviews - anyone can read approved, only logged-in users can post (no guest per requirement)
router.get('/:id/reviews', asyncHandler(async (req, res) => {
  const reviews = await prisma.review.findMany({
    where: { productId: req.params.id, isApproved: true },
    orderBy: { createdAt: 'desc' },
    include: { user: { select: { displayName: true, username: true } } },
    take: 100,
  });
  const avg = reviews.length ? (reviews.reduce((s,r)=>s+r.rating,0)/reviews.length).toFixed(1) : null;
  res.json({ reviews, average: avg, count: reviews.length });
}));

const reviewSchema = z.object({
  rating: z.number().int().min(1).max(5),
  comment: z.string().min(3).max(2000),
});

router.post('/:id/reviews', requireAuth, asyncHandler(async (req, res) => {
  const data = reviewSchema.parse(req.body);
  const product = await prisma.product.findUnique({ where: { id: req.params.id } });
  if (!product) return res.status(404).json({ error: 'Product not found' });

  // Optional: check if user purchased? For now allow any logged-in user, no guest
  const review = await prisma.review.create({
    data: {
      productId: req.params.id,
      userId: req.user.id,
      rating: data.rating,
      comment: data.comment,
      isApproved: false, // needs admin approval per requirement star_5_anon + moderation?
    },
  });
  res.status(201).json({ review, message: 'Review submitted, pending approval' });
}));

module.exports = router;
