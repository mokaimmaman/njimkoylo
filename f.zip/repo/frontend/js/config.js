window.FIAD_CONFIG = {
  // API_BASE is auto-detected in api.js:
  // - On localhost: http://localhost:4000/api
  // - On Vercel (same-origin): /api
  // - Can be overridden by setting window.FIAD_CONFIG.API_BASE before loading api.js
};
