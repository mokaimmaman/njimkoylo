# 🚀 Fiad Shop — Vercel Deployment via Termux (Mobile)

Complete guide to deploy the full-stack Fiad Shop (Frontend + Backend) to Vercel using **Termux on Android**.

---

## 📋 Prerequisites

1. **Android device** with Termux installed (from F-Droid or GitHub, NOT Play Store)
2. **GitHub account** with the repo cloned
3. **Vercel account** (free tier works)
4. **Supabase/PostgreSQL database** (free tier at supabase.com)
5. **Node.js 18+** in Termux

---

## 🛠 Termux Setup

```bash
# Update packages
pkg update && pkg upgrade -y

# Install essentials
pkg install -y git nodejs-lts python build-essential openssl

# Verify Node version (must be 18+)
node --version

# Install Vercel CLI globally
npm install -g vercel@latest

# Verify Vercel CLI
vercel --version
```

---

## 🔐 Vercel Login

```bash
# Login to Vercel (opens browser for auth)
vercel login

# Or use token (CI/CD friendly)
# Get token from: https://vercel.com/account/tokens
vercel login --token=YOUR_VERCEL_TOKEN
```

---

## 📥 Clone & Prepare Project

```bash
# Clone your fork
cd ~
git clone https://github.com/YOUR_USERNAME/fiad-shop.git
cd fiad-shop

# Install backend dependencies
cd backend
npm install

# Generate Prisma client
npx prisma generate

# Verify build works locally
npm run build
```

---

## 🗄 Database Setup (Supabase)

1. Go to [supabase.com](https://supabase.com) → New Project
2. Wait for provisioning (~2 min)
3. Go to **Settings → Database** → Copy **Connection String** (URI format)
4. Replace `[YOUR-PASSWORD]` with your database password
5. Save as `DATABASE_URL` for Vercel

**Run migrations:**
```bash
# In Termux (with DATABASE_URL set locally first)
export DATABASE_URL="postgresql://..."
npx prisma migrate deploy
```

Or use Prisma Studio locally:
```bash
npx prisma studio
```

---

## ⚙️ Environment Variables

**Set in Vercel Dashboard** (Project → Settings → Environment Variables):

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABASE_URL` | PostgreSQL connection string | `postgresql://user:pass@host:5432/db` |
| `JWT_SECRET` | 32+ char random string | `openssl rand -base64 32` |
| `CORS_ORIGINS` | Your Vercel URL | `https://fiad-shop.vercel.app` |
| `NOWPAYMENTS_API_KEY` | Crypto payments | `xxx` |
| `NOWPAYMENTS_IPN_SECRET` | Webhook secret | `xxx` |
| `BREVO_API_KEY` | Email (Brevo) | `xxx` |
| `ABLY_API_KEY` | Real-time chat | `xxx` |
| `MISTRAL_API_KEY` | AI chatbot | `xxx` |
| `NODE_ENV` | `production` | `production` |

> **Tip:** Use `vercel env add` CLI to add secrets:
> ```bash
> vercel env add DATABASE_URL production
> # Paste value when prompted
> ```

---

## 🚀 Deploy to Vercel

### Method 1: One-command deploy (recommended)

```bash
# From project root (/home/user/fiad-shop)
vercel --prod
```

### Method 2: Step by step

```bash
# 1. Link project (first time only)
vercel link

# 2. Deploy preview
vercel

# 3. Deploy to production
vercel --prod
```

### Method 3: Using vercel.json (already configured)

The repo includes `vercel.json` at root that configures:
- Frontend served from `/frontend`
- API routes at `/api/*` → `backend/src/index.js`
- Function timeout: 30s

```bash
# Just run from root
vercel --prod
```

---

## ✅ Post-Deployment

1. **Verify API health:** Visit `https://your-project.vercel.app/api/health`
2. **Seed admin user:**
   ```bash
   # Set env vars locally first, then:
   cd backend
   node prisma/seed.js
   ```
3. **Test admin login:** Go to `https://your-project.vercel.app/admin-login.html`
4. **Test frontend:** Browse products, cart, checkout flow

---

## 🔧 Troubleshooting

### "Function Runtimes must have a valid version"
```bash
# Ensure package.json has engines
# backend/package.json:
"engines": { "node": ">=18.0.0" }
```

### Prisma Client not found
```bash
# In vercel.json, ensure buildCommand runs prisma generate
# Or add postinstall script in backend/package.json:
"postinstall": "prisma generate"
```

### CORS errors
- Check `CORS_ORIGINS` includes your exact Vercel URL (no trailing slash)
- Ensure `https://` protocol

### Database connection timeout
- Supabase: Enable **Connection Pooling** (Transaction mode)
- Use pooler URL: `postgresql://user:pass@host:6543/db?pgbouncer=true`

### 500 errors on API
```bash
# Check logs
vercel logs https://your-project.vercel.app/api/health --follow
```

---

## 📱 Termux-Specific Tips

### Keep session alive
```bash
# Prevent Termux from sleeping
termux-wake-lock
# Release when done
termux-wake-unlock
```

### Use tmux for long deploys
```bash
pkg install tmux
tmux new -s deploy
# Run vercel --prod inside tmux
# Detach: Ctrl+B, D
# Reattach: tmux attach -t deploy
```

### SSH keys for GitHub
```bash
pkg install openssh
ssh-keygen -t ed25519 -C "your@email.com"
cat ~/.ssh/id_ed25519.pub
# Add to GitHub Settings → SSH Keys
```

---

## 🔄 Continuous Deployment

**Auto-deploy on push to main:**

1. Vercel Dashboard → Project → Settings → Git
2. Connect GitHub repo
3. Enable "Auto-deploy" for `main` branch
4. Every `git push origin main` triggers deploy

---

## 📁 Project Structure for Vercel

```
fiad-shop/
├── vercel.json          # Root config (this file)
├── frontend/            # Static files (served at /)
│   ├── index.html
│   ├── products.html
│   ├── product-detail.html
│   ├── admin-panel.html
│   ├── js/
│   └── ...
├── backend/             # Serverless function (served at /api)
│   ├── src/
│   │   └── index.js    # Entry point
│   ├── prisma/
│   │   └── schema.prisma
│   ├── package.json
│   └── vercel.json     # Legacy (not used)
└── DEPLOY_VERCEL_TERMUX.md
```

---

## 🎯 Key Points for Mobile/Termux

| Aspect | Command/Note |
|--------|--------------|
| **Node version** | `pkg install nodejs-lts` (v18+) |
| **Memory limits** | Vercel free: 1024MB, 30s timeout |
| **Cold starts** | First request ~2-3s (Prisma connect) |
| **Database** | Use Supabase pooler URL for serverless |
| **File uploads** | **Not supported** — use URL links only (images/videos) |
| **WebSockets** | Use Ably (configured) — Vercel doesn't support WS |

---

## 🆘 Quick Commands Reference

```bash
# Deploy
vercel --prod

# View logs
vercel logs <deployment-url>

# List deployments
vercel ls

# Remove deployment
vercel rm <deployment-url>

# Environment variables
vercel env ls
vercel env add KEY environment
vercel env rm KEY environment

# Project management
vercel link
vercel unlink
vercel inspect <deployment-url>
```

---

## ✨ What's Configured for Vercel

- ✅ **Full-stack monorepo** (frontend + API in one deploy)
- ✅ **Prisma + PostgreSQL** (Supabase compatible)
- ✅ **Serverless functions** with 30s timeout
- ✅ **CORS** configured for same-origin
- ✅ **No file uploads** — all media via URLs (Vercel compatible)
- ✅ **Images + Videos** support in products
- ✅ **Admin panel** at `/admin-panel.html`
- ✅ **Real-time chat** via Ably (WebSocket alternative)

---

**Happy deploying! 🎉**

*Built for Fiad Shop — Privacy, Excellence, Personalization & Direct Pricing*