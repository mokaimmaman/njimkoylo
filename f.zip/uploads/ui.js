/* ============================================================================
 * Fiad Shop — Shared UI: logo mount, 3-dot menu, dark mode, floating AI bot,
 * live support button, toast, cart, wishlist.
 * Loaded on every page AFTER api.js and auth.js.
 * No build step — vanilla JS, zero deps (except Tailwind + Font Awesome via CDN).
 * ========================================================================== */

(function (global) {
  'use strict';

  const { api, toast, escapeHtml } = global.FiadAPI || {
    api: { get: async () => ({}) }, toast: () => {}, escapeHtml: (s) => String(s),
  };

  // ==========================================================================
  //  LOGO — unified Fiad Shop logo, mountable via data-fiad-logo
  // ==========================================================================
  function logoHTML({ size = 'normal' } = {}) {
    const cls = size === 'small' ? 'text-base' : size === 'large' ? 'text-2xl' : 'text-xl';
    return `<a href="index.html" class="${cls} font-bold tracking-tight no-underline"><span class="text-cta-500">FIAD</span><span class="text-gray-900 dark:text-white">SHOP</span></a>`;
  }
  function mountLogos() {
    document.querySelectorAll('[data-fiad-logo]').forEach(el => {
      el.innerHTML = logoHTML({ size: el.getAttribute('data-size') || 'normal' });
    });
  }
  function replaceInline() {
    // If a page accidentally has a hardcoded logo, unify it (optional).
  }

  // ==========================================================================
  //  3-DOT MENU (user menu)
  // ==========================================================================
  function menuHTML() {
    return `
      <div class="fiad-menu-root relative inline-block">
        <button type="button"
                class="fiad-menu-btn w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100 dark:hover:bg-zinc-800 transition"
                aria-label="Menu" aria-haspopup="true" aria-expanded="false">
          <i class="fa-solid fa-ellipsis-vertical text-gray-600 dark:text-gray-400 text-sm"></i>
        </button>
        <div class="fiad-menu-panel hidden absolute right-0 mt-2 w-56 bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl shadow-xl z-[90] overflow-hidden">
          <div class="fiad-menu-body py-2"></div>
        </div>
      </div>`;
  }

  function menuItem({ icon, label, href, onClick, badge, danger }) {
    const cls =
      'flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer transition ' +
      (danger
        ? 'text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40'
        : 'text-gray-700 dark:text-gray-200 hover:bg-cta-50 dark:hover:bg-zinc-800 hover:text-cta-600 dark:hover:text-cta-400');
    const badgeHtml = badge
      ? `<span class="ml-auto text-[10px] font-bold bg-cta-500 text-white px-2 py-0.5 rounded-full">${escapeHtml(badge)}</span>`
      : '';
    const iconHtml = `<i class="fa-solid ${icon} w-4 text-center"></i>`;
    const inner = `${iconHtml}<span class="flex-1">${escapeHtml(label)}</span>${badgeHtml}`;
    if (onClick) {
      return `<button type="button" role="menuitem" class="${cls} w-full text-left" data-onclick="${onClick}">${inner}</button>`;
    }
    return `<a role="menuitem" href="${href}" class="${cls}">${inner}</a>`;
  }

  function renderMenuBody(panelBody) {
    const user = global.FiadAuth?.getUser();
    const isAdmin = global.FiadAuth?.isAdmin();
    const isAff = global.FiadAuth?.isAffiliate();

    const items = [];

    if (user) {
      items.push(`
        <div class="px-3 py-2 border-b border-gray-100 dark:border-zinc-800">
          <div class="text-xs text-gray-500 dark:text-gray-400">Signed in as</div>
          <div class="font-semibold truncate">Hi, ${escapeHtml(user.displayName || user.username || 'friend')}</div>
        </div>`);
      items.push(menuItem({ icon: 'fa-bag-shopping', label: 'Shop Now',       href: 'products.html' }));
      items.push(menuItem({ icon: 'fa-lightbulb',    label: 'Earn With Us',   href: 'earn-with-us.html' }));
      if (isAff) {
        items.push(menuItem({ icon: 'fa-chart-line', label: 'Affiliate Dashboard', href: 'affiliate-dashboard.html', badge: 'Pro' }));
      } else {
        items.push(menuItem({ icon: 'fa-rocket',     label: 'Open Pro Account', onClick: 'openProAccount' }));
      }
      items.push(menuItem({ icon: 'fa-robot',        label: 'AI Chat',        href: 'ai.html' }));
      items.push(menuItem({ icon: 'fa-box',          label: 'My Orders',      href: 'order-tracking.html' }));
      items.push(menuItem({ icon: 'fa-user-gear',    label: 'Profile Settings', href: 'login.html#profile' }));
      if (isAdmin) {
        items.push(menuItem({ icon: 'fa-shield-halved', label: 'Admin Panel', href: 'admin-panel.html', badge: 'Admin' }));
      }
      items.push(`<div class="my-1 border-t border-gray-100 dark:border-zinc-800"></div>`);
      items.push(menuItem({ icon: 'fa-arrow-right-from-bracket', label: 'Logout', onClick: 'logout', danger: true }));
    } else {
      items.push(menuItem({ icon: 'fa-bag-shopping', label: 'Shop Now',     href: 'products.html' }));
      items.push(menuItem({ icon: 'fa-lightbulb',    label: 'Earn With Us', href: 'earn-with-us.html' }));
      items.push(menuItem({ icon: 'fa-robot',        label: 'AI Chat',      href: 'ai.html' }));
      items.push(`<div class="my-1 border-t border-gray-100 dark:border-zinc-800"></div>`);
      items.push(menuItem({ icon: 'fa-right-to-bracket', label: 'Login / Register', href: 'login.html' }));
    }

    panelBody.innerHTML = items.join('');

    // Wire button-onclick actions
    panelBody.querySelectorAll('[data-onclick]').forEach(btn => {
      const action = btn.getAttribute('data-onclick');
      btn.addEventListener('click', async () => {
        if (action === 'logout') {
          global.FiadAuth.logout();
        } else if (action === 'openProAccount') {
          try {
            await api.post('/affiliate/apply', {});
            toast('Welcome — you are now an affiliate!', 'success');
            await global.FiadAuth.refreshMe();
            setTimeout(() => { location.href = 'affiliate-dashboard.html'; }, 500);
          } catch (e) {
            toast(e.message || 'Could not open Pro account', 'error');
          }
        }
      });
    });
  }

  function mountMenus() {
    document.querySelectorAll('[data-fiad-menu]').forEach(el => {
      el.innerHTML = menuHTML();
      const root = el.querySelector('.fiad-menu-root');
      const btn = root.querySelector('.fiad-menu-btn');
      const panel = root.querySelector('.fiad-menu-panel');
      const body = root.querySelector('.fiad-menu-body');

      const open = () => {
        renderMenuBody(body);
        panel.classList.remove('hidden');
        btn.setAttribute('aria-expanded', 'true');
      };
      const close = () => {
        panel.classList.add('hidden');
        btn.setAttribute('aria-expanded', 'false');
      };
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        panel.classList.contains('hidden') ? open() : close();
      });
      document.addEventListener('click', (e) => {
        if (!root.contains(e.target)) close();
      });
      document.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
    });
  }

  // Re-render open menus after auth state changes
  document.addEventListener('fiad:auth-changed', () => {
    document.querySelectorAll('.fiad-menu-panel .fiad-menu-body').forEach(renderMenuBody);
  });

  // ==========================================================================
  //  DARK MODE — unified handling for emoji 🔆 / 🌙, supports both <i> and <span>
  //  Day mode (light) => 🌙 (click to go dark)  Night mode (dark) => 🔆 (click to go light) - action mode
  //  Also syncs both localStorage keys 'theme' and 'fiad_theme' for compatibility
  // ==========================================================================
  function initDarkMode() {
    const KEY1 = 'theme';
    const KEY2 = 'fiad_theme';
    const html = document.documentElement;
    
    // Read stored theme from either key
    const stored = localStorage.getItem(KEY2) || localStorage.getItem(KEY1);
    const prefersDark = !!(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
    
    if (stored === 'dark' || (!stored && prefersDark)) html.classList.add('dark');

    function apply(dark) {
      html.classList.toggle('dark', dark);
      try {
        localStorage.setItem(KEY1, dark ? 'dark' : 'light');
        localStorage.setItem(KEY2, dark ? 'dark' : 'light');
      } catch(e){}
      
      document.querySelectorAll('#theme-icon').forEach(icon => {
        if (!icon) return;
        if (icon.tagName === 'I') {
          // Legacy FontAwesome path
          icon.classList.remove('fa-moon', 'fa-sun');
          icon.classList.add(dark ? 'fa-moon' : 'fa-sun');
          // If user wanted emoji, we also handle: replace <i> with span if needed
          // But keep icon class for compatibility
        } else {
          // Emoji path - action mode: light => 🌙, dark => 🔆
          // Actually for current-mode display: light=>🔆, dark=>🌙
          icon.textContent = dark ? '🔆' : '🌙';
        }
      });
    }
    
    // Initial apply
    apply(html.classList.contains('dark'));

    // Bind all toggle buttons
    document.querySelectorAll('#dark-mode-toggle').forEach(btn => {
      // Remove old listeners by cloning? Instead just add new, and stopPropagation
      const newBtn = btn.cloneNode(true);
      btn.parentNode.replaceChild(newBtn, btn);
      newBtn.addEventListener('click', (e) => {
        e.preventDefault();
        const isDark = html.classList.contains('dark');
        apply(!isDark);
      });
    });
  }

  // ==========================================================================
  //  FLOATING AI BOT
  // ==========================================================================
  function mountFloatingAi() {
    if (document.querySelector('.fiad-fab-ai')) return;
    const path = location.pathname.toLowerCase();
    if (path.endsWith('/ai.html') || path.includes('admin-')) return;

    const wrap = document.createElement('div');
    wrap.className = 'fiad-fab-ai fixed z-[80] bottom-5 right-5 flex flex-col items-end gap-2';
    wrap.innerHTML = `
      <a href="ai.html"
         class="group flex items-center gap-2 bg-cta-500 hover:bg-cta-600 text-white pl-3 pr-4 py-3 rounded-full shadow-lg shadow-cta-500/30 transition-all hover:scale-105"
         aria-label="Ask Fiad AI">
        <span class="relative inline-flex items-center justify-center w-6 h-6 rounded-full bg-white/20">
          <i class="fa-solid fa-robot text-sm"></i>
          <span class="absolute -top-1 -right-1 w-2.5 h-2.5 bg-green-400 rounded-full ring-2 ring-cta-500"></span>
        </span>
        <span class="hidden xs:inline text-sm font-bold">Ask Fiad AI</span>
      </a>`;
    document.body.appendChild(wrap);
  }

  // ==========================================================================
  //  LIVE SUPPORT BUTTON
  // ==========================================================================
  async function mountLiveSupport() {
    if (document.querySelector('.fiad-fab-support')) return;
    let status;
    try { status = await api.get('/support/status'); }
    catch { return; }

    const wrap = document.createElement('div');
    wrap.className = 'fiad-fab-support fixed z-[81] bottom-20 right-5';

    if (status.isLiveEnabled) {
      wrap.innerHTML = `
        <button type="button"
                class="flex items-center gap-2 bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 hover:border-cta-500 text-gray-800 dark:text-gray-100 pl-3 pr-4 py-2.5 rounded-full shadow-lg transition-all hover:scale-105"
                aria-label="Chat with support">
          <span class="relative inline-flex items-center justify-center w-6 h-6 rounded-full bg-green-100 dark:bg-green-900/40 text-green-600 dark:text-green-400">
            <i class="fa-solid fa-headset text-xs"></i>
            <span class="absolute -top-0.5 -right-0.5 w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
          </span>
          <span class="hidden xs:inline text-xs font-semibold">Live Support</span>
        </button>`;
    } else {
      wrap.innerHTML = `
        <button type="button"
                class="flex items-center gap-2 bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 text-gray-500 dark:text-gray-400 pl-3 pr-4 py-2.5 rounded-full shadow-lg transition-all hover:border-cta-500"
                aria-label="Leave a message">
          <span class="relative inline-flex items-center justify-center w-6 h-6 rounded-full bg-gray-100 dark:bg-zinc-800">
            <i class="fa-solid fa-envelope text-xs"></i>
          </span>
          <span class="hidden xs:inline text-xs font-semibold">Leave a message</span>
        </button>`;
    }

    document.body.appendChild(wrap);
    wrap.querySelector('button').addEventListener('click', () => {
      if (status.isLiveEnabled && global.FiadSupportChat?.openCustomer) {
        global.FiadSupportChat.openCustomer();
      } else {
        openSupportChat(status);
      }
    });
  }

  function openSupportChat(status) {
    const existing = document.getElementById('fiad-support-modal');
    if (existing) { existing.remove(); return; }

    const online = status.isLiveEnabled;
    const modal = document.createElement('div');
    modal.id = 'fiad-support-modal';
    modal.className = 'fixed inset-0 z-[9998] flex items-end sm:items-center justify-center bg-black/40 p-4';
    modal.innerHTML = `
      <div class="bg-white dark:bg-zinc-900 rounded-xl shadow-2xl w-full max-w-md overflow-hidden">
        <div class="flex items-center gap-3 px-4 py-3 border-b border-gray-100 dark:border-zinc-800">
          <div class="w-9 h-9 rounded-full bg-cta-500 text-white flex items-center justify-center">
            <i class="fa-solid fa-headset text-xs"></i>
          </div>
          <div class="flex-1">
            <div class="text-sm font-bold">Support</div>
            <div class="text-[10px] ${online ? 'text-green-600' : 'text-gray-500'}">${online ? '● Online' : '○ Offline'}</div>
          </div>
          <button class="text-gray-400 hover:text-gray-600 p-1" onclick="document.getElementById('fiad-support-modal').remove()"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="p-4">
          <p class="text-sm text-gray-600 dark:text-gray-300 mb-3">${escapeHtml(status.offlineMessage || (online ? 'How can we help you today?' : 'Leave us a message and we will get back to you.'))}</p>
          <input id="sup-email" type="email" placeholder="Your email"
                 class="w-full px-3 py-2 border rounded-lg bg-gray-50 dark:bg-zinc-800 border-gray-200 dark:border-zinc-700 text-sm mb-2 focus:border-cta-500 focus:outline-none">
          <textarea id="sup-msg" rows="3" placeholder="How can we help?"
                    class="w-full px-3 py-2 border rounded-lg bg-gray-50 dark:bg-zinc-800 border-gray-200 dark:border-zinc-700 text-sm focus:border-cta-500 focus:outline-none"></textarea>
          <button id="sup-send" class="mt-3 w-full bg-cta-500 hover:bg-cta-600 text-white py-2.5 rounded-lg text-sm font-bold">Send message</button>
        </div>
      </div>`;
    document.body.appendChild(modal);

    modal.querySelector('#sup-send').addEventListener('click', async () => {
      const email = modal.querySelector('#sup-email').value.trim();
      const message = modal.querySelector('#sup-msg').value.trim();
      if (!email || !message) return toast('Please fill all fields', 'warn');
      try {
        const { sessionId } = await api.post('/support/session', { email });
        await api.post('/support/session/' + sessionId + '/message', { sender: 'user', message });
        toast('Message sent! We will reply soon.', 'success');
        modal.remove();
      } catch (e) { toast(e.message || 'Failed', 'error'); }
    });
  }

  // ==========================================================================
  //  BOOT
  // ==========================================================================
  function boot() {
    const steps = [
      ['mountLogos',       mountLogos],
      ['mountMenus',       mountMenus],
      ['initDarkMode',     initDarkMode],
      ['mountFloatingAi',  mountFloatingAi],
      ['mountLiveSupport', mountLiveSupport],
    ];
    for (const [name, fn] of steps) {
      try { fn(); }
      catch (e) { console.error('[FiadUI:' + name + ']', e); }
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  global.FiadUI = { logoHTML, mountLogos, mountMenus, replaceInline, boot, initDarkMode };
})(window);
