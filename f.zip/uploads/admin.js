// Admin panel APIs. Every route requires role=ADMIN (some also allow MODERATOR).

const express = require('express');
const { z } = require('zod');
const bcrypt = require('bcryptjs');
const prisma = require('../lib/prisma');
const { requireAuth } = require('../middleware/auth');
const { requireRole } = require('../middleware/roleCheck');
const asyncHandler = require('../lib/asyncHandler');
const { generateUniqueCouponCode } = require('../utils/couponGenerator');
const { sendCouponEmail } = require('../lib/email');
const { sendShippedNotice } = require('../controllers/orderController');

const router = express.Router();

router.use(requireAuth, requireRole('ADMIN', 'MODERATOR'));

// -----------------------------------------------------------------------------
// Dashboard summary
// -----------------------------------------------------------------------------
router.get('/dashboard', asyncHandler(async (_req, res) => {
  const [orders, users, affiliates, revenue, pendingFeedback, activeSessions] = await Promise.all([
    prisma.order.count(),
    prisma.user.count(),
    prisma.affiliate.count(),
    prisma.order.aggregate({ _sum: { total: true }, where: { status: { in: ['PAID','APPROVED','SHIPPED','DELIVERED'] } } }),
    prisma.feedback.count({ where: { status: 'PENDING' } }),
    prisma.liveSupportSession.count({ where: { status: { in: ['ACTIVE','WAITING'] } } }),
  ]);
  const recentOrders = await prisma.order.findMany({
    orderBy: { createdAt: 'desc' }, take: 10,
    select: { id: true, orderNumber: true, total: true, status: true, createdAt: true, guestEmail: true, userId: true },
  });
  res.json({
    counts: { orders, users, affiliates, pendingFeedback, activeSessions },
    revenue: revenue._sum.total || 0,
    recentOrders,
  });
}));

// -----------------------------------------------------------------------------
// PRODUCTS
// -----------------------------------------------------------------------------
const productSchema = z.object({
  sku: z.string().min(1).max(80),
  pid: z.string().min(1).max(80),
  name: z.string().min(1).max(200),
  description: z.string().max(20000),
  category: z.string().min(1).max(80),
  basePrice: z.number().nonnegative(),
  images: z.array(z.string().url()).max(20).default([]),
  videos: z.array(z.string().url()).max(10).default([]),
  affiliateCommission: z.number().min(0).max(90).default(0),
  isProMode: z.boolean().default(false),
  isPackage: z.boolean().default(false),
  isActive: z.boolean().default(true),
  stock: z.number().int().min(0).default(0),
  variants: z.array(z.object({
    color: z.string().optional().nullable(),
    size: z.string().optional().nullable(),
    material: z.string().optional().nullable(),
    priceOverride: z.number().optional().nullable(),
    stock: z.number().int().min(0).default(0),
  })).optional(),
  packageItems: z.array(z.object({
    childProductId: z.string(),
    quantity: z.number().int().min(1),
  })).optional(),
});

router.get('/products', asyncHandler(async (req, res) => {
  const items = await prisma.product.findMany({
    orderBy: { createdAt: 'desc' },
    include: { 
      variants: true, 
      packageItems: { include: { childProduct: { select: { id: true, name: true, sku: true, basePrice: true } } } } 
    },
    take: 500,
  });
  res.json({ items });
}));

router.post('/products', asyncHandler(async (req, res) => {
  const data = productSchema.parse(req.body);

  // Validate package items exist
  if (data.isPackage && data.packageItems?.length) {
    const childIds = data.packageItems.map(pi => pi.childProductId);
    const existing = await prisma.product.findMany({ where: { id: { in: childIds } }, select: { id: true } });
    const existingIds = new Set(existing.map(e => e.id));
    const missing = childIds.filter(id => !existingIds.has(id));
    if (missing.length) return res.status(400).json({ error: `Child products not found: ${missing.join(', ')}` });
  }

  const { variants = [], packageItems = [], ...prod } = data;
  const created = await prisma.product.create({
    data: {
      ...prod,
      images: prod.images || [],
      videos: prod.videos || [],
      variants: { create: variants },
      packageItems: { create: packageItems },
    },
    include: { variants: true, packageItems: { include: { childProduct: true } } },
  });
  res.status(201).json({ product: created });
}));

router.put('/products/:id', asyncHandler(async (req, res) => {
  const data = productSchema.partial().parse(req.body);
  const { variants, packageItems, ...prod } = data;

  if (prod.isPackage && packageItems && packageItems.length === 0) {
    // allow empty during transition but warn
  }

  if (packageItems?.length) {
    const childIds = packageItems.map(pi => pi.childProductId);
    // Prevent self-reference
    if (childIds.includes(req.params.id)) return res.status(400).json({ error: 'Package cannot contain itself' });
    const existing = await prisma.product.findMany({ where: { id: { in: childIds } }, select: { id: true } });
    const existingIds = new Set(existing.map(e => e.id));
    const missing = childIds.filter(id => !existingIds.has(id));
    if (missing.length) return res.status(400).json({ error: `Child products not found: ${missing.join(', ')}` });
  }

  // Do variant/packageItem replace-all in a transaction for simplicity.
  const updated = await prisma.$transaction(async (tx) => {
    const p = await tx.product.update({ where: { id: req.params.id }, data: prod });
    if (variants) {
      await tx.productVariant.deleteMany({ where: { productId: p.id } });
      if (variants.length) {
        await tx.productVariant.createMany({
          data: variants.map(v => ({ ...v, productId: p.id })),
        });
      }
    }
    if (packageItems) {
      await tx.packageItem.deleteMany({ where: { packageId: p.id } });
      if (packageItems.length) {
        await tx.packageItem.createMany({
          data: packageItems.map(pi => ({ ...pi, packageId: p.id })),
        });
      }
    }
    return tx.product.findUnique({
      where: { id: p.id },
      include: { variants: true, packageItems: { include: { childProduct: true } } },
    });
  });
  res.json({ product: updated });
}));

router.delete('/products/:id', asyncHandler(async (req, res) => {
  const id = req.params.id;
  
  // Check if product is used in orders
  const orderItemCount = await prisma.orderItem.count({ where: { productId: id } });
  if (orderItemCount > 0) {
    // Soft delete - set inactive instead of hard delete
    const updated = await prisma.product.update({ 
      where: { id }, 
      data: { isActive: false } 
    });
    return res.json({ ok: true, softDeleted: true, message: `Product has ${orderItemCount} order references, set to inactive instead.`, product: updated });
  }

  // Check if product is child in any package
  const packageUsage = await prisma.packageItem.count({ where: { childProductId: id } });
  if (packageUsage > 0) {
    return res.status(400).json({ 
      error: `Cannot delete: Product is used as item in ${packageUsage} package(s). Remove it from packages first or deactivate instead.`,
      code: 'USED_IN_PACKAGE'
    });
  }

  try {
    await prisma.$transaction(async (tx) => {
      await tx.productVariant.deleteMany({ where: { productId: id } });
      await tx.packageItem.deleteMany({ where: { packageId: id } });
      // Also delete any orphaned package child refs? Already checked above
      await tx.product.delete({ where: { id } });
    });
    res.json({ ok: true });
  } catch (e) {
    console.error('[admin] delete failed:', e.message);
    // Fallback soft delete
    try {
      const updated = await prisma.product.update({ where: { id }, data: { isActive: false } });
      return res.json({ ok: true, softDeleted: true, message: 'Hard delete failed, set to inactive instead', product: updated });
    } catch (e2) {
      return res.status(500).json({ error: 'Delete failed: ' + e.message });
    }
  }
}));

// Deactivate / Reactivate helper
router.post('/products/:id/toggle-active', asyncHandler(async (req, res) => {
  const product = await prisma.product.findUnique({ where: { id: req.params.id } });
  if (!product) return res.status(404).json({ error: 'Not found' });
  const updated = await prisma.product.update({ where: { id: req.params.id }, data: { isActive: !product.isActive } });
  res.json({ product: updated });
}));

// -----------------------------------------------------------------------------
// ORDERS
// -----------------------------------------------------------------------------
router.get('/orders', asyncHandler(async (req, res) => {
  const { status, affiliateId, from, to } = req.query;
  const where = {};
  if (status) where.status = status;
  if (affiliateId) where.affiliateId = affiliateId;
  if (from || to) {
    where.createdAt = {};
    if (from) where.createdAt.gte = new Date(from);
    if (to) where.createdAt.lte = new Date(to);
  }
  const orders = await prisma.order.findMany({
    where, orderBy: { createdAt: 'desc' }, take: 200,
    include: { items: true, user: { select: { email: true, displayName: true } } },
  });
  res.json({ orders });
}));

router.get('/orders/:id', asyncHandler(async (req, res) => {
  const order = await prisma.order.findUnique({
    where: { id: req.params.id },
    include: {
      items: { include: { product: { select: { sku: true, pid: true, name: true } } } },
      user: { select: { email: true, displayName: true, username: true } },
      affiliate: { include: { user: { select: { displayName: true, email: true } } } },
      coupon: true,
    },
  });
  if (!order) return res.status(404).json({ error: 'Not found' });
  res.json({ order });
}));

router.post('/orders/:id/approve', asyncHandler(async (req, res) => {
  const order = await prisma.order.update({
    where: { id: req.params.id },
    data: { status: 'APPROVED' },
    include: {
      items: { include: { product: { select: { sku: true, pid: true, name: true } } } },
    },
  });
  // Build "CJ forward" payload the admin can copy
  const cjForward = {
    shippingAddress: order.shippingAddress,
    items: order.items.map(i => ({
      sku: i.sku, pid: i.product?.pid, name: i.name, quantity: i.quantity, variant: i.variantJson,
    })),
    orderNumber: order.orderNumber,
  };
  res.json({ order, cjForward });
}));

router.post('/orders/:id/reject', asyncHandler(async (req, res) => {
  const { reason } = z.object({ reason: z.string().max(500).optional() }).parse(req.body || {});
  const order = await prisma.order.update({
    where: { id: req.params.id },
    data: { status: 'REJECTED', adminNotes: reason || null },
  });
  res.json({ order });
}));

router.post('/orders/:id/ship', asyncHandler(async (req, res) => {
  const { trackingNumber, trackingCarrier } = z.object({
    trackingNumber: z.string().min(3).max(80),
    trackingCarrier: z.string().max(80).optional(),
  }).parse(req.body);

  const order = await prisma.order.update({
    where: { id: req.params.id },
    data: { trackingNumber, trackingCarrier: trackingCarrier || null, status: 'SHIPPED', shippedAt: new Date() },
  });

  sendShippedNotice(order).catch(()=>{});

  res.json({ order });
}));

router.post('/orders/:id/deliver', asyncHandler(async (req, res) => {
  const order = await prisma.order.update({
    where: { id: req.params.id },
    data: { status: 'DELIVERED', deliveredAt: new Date() },
  });
  res.json({ order });
}));

module.exports = router;
