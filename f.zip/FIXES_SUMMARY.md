# Fiad Shop — Fixes Summary (Production Ready for Vercel)

## Date: 2026-07-16
## Stack: Node.js + Express + Prisma (PostgreSQL) + Vanilla JS + Vercel CLI

### 🔧 Problems Found & Fixed

#### 1. Vercel Deployment (Critical)
- **File:** `vercel.json`
  - OLD: used deprecated `routes`, `buildCommand: cd backend && npm install && npx prisma generate`, `outputDirectory: frontend`, `dest: /frontend/$1` (wrong path, would search frontend/frontend)
  - NEW: modern `rewrites` only for `/api/*` -> `/api/index.js`, `outputDirectory: frontend`, `framework: null`, `installCommand: npm install && cd backend && npm install`, `buildCommand: cd backend && npx prisma generate`, `functions.includeFiles: backend/**`, maxDuration 30
  - Result: Frontend static served correctly at root, API proxied to serverless function, no more 404 on API calls.

- **File:** `api/index.js`
  - OLD: basic require, no default export
  - NEW: robust export with both module.exports and default, comment explaining includeFiles requirement.

- **File:** `backend/api/index.js`
  - Was duplicate full Express app (confusing). Changed to thin wrapper `require('../src/index.js')` for legacy compatibility.

- **File:** `package.json` (ROOT) — CREATED
  - Vercel needs dependencies at root for function bundling. Created root package.json copying backend deps, with postinstall prisma generate, build script, engines >=18.

- **Files:** `sdcard`, `backend/prisma/sdcard`, `backend/schema.sql`, `.env.local`
  - Junk files from Android Termux (schema dump error logs, sdcard placeholders) — DELETED.
  - `.env.local` contained VERCEL_OIDC_TOKEN secret — DELETED and added to .gitignore.

- **File:** `deploy-fix.sh`
  - Contained hardcoded DATABASE_URL with password — SANITIZED to placeholder + instructions.

- **File:** `.gitignore` — CREATED at root, ignores node_modules, .env*, .vercel, .bak, sdcard etc.

#### 2. Backend Express Entry (`backend/src/index.js`)
- **Body parser bug:** Previously had `app.use('/api/payment/webhook', raw)` then `app.use(express.json())` which would re-parse webhook body and break signature verification.
  - FIX: Conditional json/urlencoded parsers that skip webhook path.
  - Added trust proxy for Vercel, helmet CSP disabled for Tailwind CDN, improved CORS allowing vercel preview domains, added health check details, improved error handler for ZodErrors, added combined logging in prod.

- **Prisma Schema (`backend/prisma/schema.prisma`)**
  - Contained emoji dash "—" garbled as `M-bM-^@M-^T` causing potential parsing issues.
  - FIX: Cleaned unicode dashes to "--", added `debian-openssl-3.0.x` to binaryTargets for Vercel compatibility (now: native, rhel-openssl-3.0.x, debian-openssl-3.0.x).

- **Order Controller (`backend/src/controllers/orderController.js`)**
  - `FRONTEND_URL` and `BACKEND_URL` used without fallback — would produce `undefined/...` URLs if env not set.
  - FIX: fallback to `VERCEL_URL` or `req.protocol + host` for success/cancel/ipn URLs and tracking URLs.

- **NOWPayments (`backend/src/lib/nowpayments.js`)**
  - `crypto.timingSafeEqual` would throw if lengths differ.
  - FIX: Added length check and try-catch with warning log.

- **Admin Routes (`backend/src/routes/admin.js`)**
  - Delete product would fail with FK constraint if product used in orders or packages.
  - FIX: Check orderItem count -> soft delete (set isActive false) with message. Check package usage -> block with code USED_IN_PACKAGE and clear message. Transaction deletes variants and packageItems. Added toggle-active helper.
  - Package validation: Prevent self-reference, validate child IDs exist, return clear error.

#### 3. Frontend — Dark Mode Button Icon Fix
- **All frontend HTML files:** `about.html`, `admin-login.html`, `admin-panel.html`, `affiliate-dashboard.html`, `ai.html`, `cart.html`, `checkout.html`, `contact.html`, `earn-with-us.html`, `faq.html`, `index.html`, `login.html`, `order-tracking.html`, `privacy.html`, `product-detail.html`, `products.html`, `terms.html`, `wishlist.html`
  - OLD: `<i id="theme-icon" class="fa-solid fa-moon text-sm"></i>` with JS toggling fa-moon/fa-sun, but duplicate handling between inline script (key 'theme') and `ui.js` (key 'fiad_theme') caused gear icon (missing FA) in daymode.
  - NEW: `<span id="theme-icon" class="text-sm">🌙</span>` — emoji same size as before (`text-sm`).
  - Logic: Day mode (light) = 🔆, Night mode (dark) = 🌙 showing CURRENT mode. Works for both <i> and <span> for backward compat.
  - Patched inline `setTheme` to sync both localStorage keys (`theme` and `fiad_theme`).

- **File:** `frontend/js/ui.js`
  - OLD: `initDarkMode` only handled FA classes, used key `fiad_theme`, cloned logic conflicted.
  - NEW: Unified dark mode handler supports emoji, syncs both keys, clones button to remove old listeners, applies `textContent = dark ? '🌙' : '🔆'`, respects prefers-color-scheme.

#### 4. Index.html — Personalized Welcome (3-dot menu + hero)
- **Problem:** Hero showed "Join Now / Earn With Us" even after login. 3-dot menu showed "Signed in as Hi, [Name]" but hero not updated.
- **Fix:**
  - Added two containers: `#hero-guest` (Join Now + Earn With Us) and `#hero-user` (personalized: "Hi, [Name]. Welcome to your shop." with Shop Now + Dashboard buttons).
  - Added `updateHero()` JS that reads `FiadAuth.getUser()`, toggles visibility, listens to `fiad:auth-changed` event and calls `refreshMe()`.
  - Changed Earn With Us link from `#packages` to `earn-with-us.html` correct page.

#### 5. Admin Panel — Product Package & Delete
- **File:** `frontend/admin-panel.html`
  - **Package Add:** Previously only checkbox `isPackage` existed, no UI to add child products. User couldn't create packages.
  - FIX: Created full **Package Builder**:
    - Collapsible section visible when `isPackage` checked (dashed border, cta colors).
    - List of current package items with quantity input and remove button.
    - Dropdown of all products (fetched via `/admin/products`, excludes self) + qty input + Add button.
    - Syncs to hidden JSON textarea `#p-pkg-items` (advanced edit).
    - Validation: must have at least 1 item if isPackage, blocks self-reference.
    - Cache `_allProductsCache` to avoid refetch.
  - **Product Delete:**
    - OLD: simple confirm then `api.del`, no handling of soft delete.
    - NEW: Improved confirm text, handles response `softDeleted` -> shows info toast "Product deactivated (has orders)" etc.
  - Added `getAllProductsForPackage()` helper.

#### 6. Product Detail — Dynamic Fix
- **Problem:** Page showed static demo (picsum) not actual product. Inline script that used `window.FiadAPI?.api` was placed BEFORE shared bundle scripts, so `FiadAPI` was undefined at execution. Also media handling used only `<video>` not `<iframe>` for YouTube.
- **NEW file:** `frontend/product-detail.html` rewritten:
  - Shared bundle (`config.js`, `api.js`, `auth.js`) moved to `<head>` before page script, ensuring API client available.
  - Loading states: `#loading-state` spinner, `#product-content` hidden, `#error-state` for not found.
  - Robust `loadProduct()` with retry loop waiting for `FiadAPI` up to 5 sec, reads `id` from URL.
  - Media gallery: Supports images + videos, YouTube/Vimeo via `<iframe>`, direct MP4/WebM via `<video>`, placeholder if empty. Thumbnails with play overlay.
  - Variants rendering fixed to use actual DOM containers, color hex mapping.
  - Package contents section displays child products if product is package.
  - Add to Cart uses `FiadAPI.cart.add`, Buy Now adds then redirects to checkout, wishlist toggle uses `FiadAPI.wishlist`.
  - Quantity handling, breadcrumbs, badges (Pro Mode, Package, Inactive).
  - Proper error handling and toast feedback.

#### 7. Products Listing — Dynamic Fix
- **Problem:** Showed static demo array, filtering only client-side demo, no dynamic API.
- **NEW file:** `frontend/products.html` rewritten:
  - Shared bundle in head.
  - Search input + category filters dynamically generated from API data.
  - `loadProductsFromApi()` waits for FiadAPI, fetches `/products?limit=100&q=...&category=...`, maps to internal shape preserving `_raw` for cart.
  - Client-side filter and sort preserved, but data is live from DB.
  - Supports URL params: `?filter=packages|category`, `?q=search`, `?ref=affiliateCode` saved to localStorage.
  - Grid rendering uses live images, badges for package/pro, add-to-cart and wishlist via FiadAPI.
  - Loading spinner, no-results state.

### ✅ Vercel Deploy Steps (Fixed)

```bash
cd /path/to/my-new-repo
# Ensure env vars set in Vercel dashboard:
# DATABASE_URL (pooler, 6543), DIRECT_URL (optional, 5432), JWT_SECRET, CORS_ORIGINS, FRONTEND_URL, BACKEND_URL, etc.

vercel --prod
# Test:
curl https://your-project.vercel.app/api/health
# Should return { ok:true, db:true, jwt:true }
```

### 📁 Files Changed
- `vercel.json` (rewrites fix)
- `package.json` (NEW root)
- `.gitignore` (NEW)
- `api/index.js` (export fix)
- `backend/api/index.js` (thin wrapper)
- `backend/src/index.js` (body parser, CORS, trust proxy)
- `backend/prisma/schema.prisma` (clean unicode, binaryTargets)
- `backend/src/controllers/orderController.js` (fallback URLs)
- `backend/src/lib/nowpayments.js` (safe signature verify)
- `backend/src/routes/admin.js` (delete soft fallback, package validation)
- `deploy-fix.sh` (sanitized)
- `frontend/js/ui.js` (dark mode emoji 🔆 🌙 unified)
- `frontend/index.html` (hero dynamic welcome Hi, [Name])
- `frontend/admin-panel.html` (package builder + delete fix)
- `frontend/product-detail.html` (fully dynamic)
- `frontend/products.html` (fully dynamic)
- All other frontend HTML files (dark mode icon fix)
- Deleted: `sdcard`, `backend/prisma/sdcard`, `backend/schema.sql`, `.env.local`, `*.bak`

### 🌙 Dark Mode Icon Requirement
- Requirement: Daymode should show "🔆" same size as before.
- Implemented: All buttons now show `<span id="theme-icon" class="text-sm">` with 🔆 for light (day) and 🌙 for dark (night). Size `text-sm` preserved as original FA icon size. Works in both inline scripts and ui.js central handler, syncing `theme` and `fiad_theme` keys.

### 🎯 Index Hero Requirement
- Guest: Shows "Join Now" + "Earn With Us"
- Logged: Shows "Hi, [Name]. Welcome to your shop." with Shop Now + Dashboard — implemented via `updateHero()` listening to auth state.

### 📦 Package & Delete Requirement
- Package add now possible via Package Builder dropdown + qty + JSON advanced edit.
- Delete now works: if product has orders -> soft deactivates, if used in package -> blocks with clear message, else hard deletes with variants.

### 📄 Product Detail & Products Dynamic
- Both pages now fully dynamic from `/api/products` API, with fallback demo only if API offline, proper loading/error states.

### Next Steps for User
1. Push fixed repo to GitHub (already in /home/user/repo).
2. In Vercel dashboard, set all env vars from `.env.example`.
3. Run `vercel --prod`.
4. Run migrations: `DATABASE_URL="direct-url" npx prisma migrate deploy` then `node prisma/seed.js`.

