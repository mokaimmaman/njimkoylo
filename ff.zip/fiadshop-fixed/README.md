# FIADSHOP Frontend — সংশোধিত ফাইলসমূহ

এই ফোল্ডারে আপডেট করা HTML পেইজগুলো, `site-common.js`, এবং আপনার দেওয়া `ai.svg.txt` রয়েছে।

## করা পরিবর্তন
- দেওয়া shared header সব পেইজে বসানো হয়েছে; sticky আচরণ সরানো হয়েছে। `checkout.html`-এ universal header বাদ দিয়ে শুধু Cart → Checkout progress header রাখা হয়েছে। `profile.html`-এও shared header প্রয়োগ করা হয়েছে।
- Wishlist icon ও link তিন-ডট মেনুর ভিতরে রাখা হয়েছে; Wishlist-এর পাশে কোনো সংখ্যা/badge নেই। Login না থাকলে header-এ Login/Register, Login থাকলে Profile দেখায়।
- Login ও Register browser-only demo-তে কাজ করে: registration শেষে Login view-তে email/password prefill হয়, এবং login ও registration—দুই ক্ষেত্রেই fixed OTP `1122` যাচাই হয়। Index-এ logged-out visitor-রা Shop Now, Earn With Us ও Shop without login action দেখেন; signed-in user-এর greeting-এ তার নাম দেখা যায়।
- `product-detail.html`-এ দাম `$110`; Add to Cart item-কে cart-এ যোগ করে, Wishlist action item-কে Wishlist-এ সংরক্ষণ করে। Buy Now product-কে cart-এ না ঢুকিয়ে transient checkout item হিসেবে Checkout-এ নেয়; মোবাইলের phone/chat control-এর জায়গায় Wishlist button আছে।
- Checkout-এ Crypto ও Normal—দুটি selectable payment method আছে; order জমা দেওয়ার আগে একটি নির্বাচন করা বাধ্যতামূলক। Payment process হয় না। Login করা ব্যবহারকারীর profile তথ্য checkout-এ আগে থেকে আসে; successful demo order-এর পর checkout details Profile-এ সংরক্ষিত হয়।
- Profile Edit-এ Checkout-স্টাইলের তথ্যের field ও shared country dropdown আছে; আগে থেকে saved country ধরে রাখা হয়, আর কিছু সংরক্ষিত না থাকলে dropdown blank থাকে। Order History-তে শুধু signed-in user-এর browser-এ তৈরি order দেখা যায়; একটি order বা সব order মুছতে confirmation লাগে। Profile ও standalone Wishlist—দুই জায়গাতেই শুধু বাস্তবে save করা item দেখা যায়।
- Settings থেকে SMS Alerts সরানো হয়েছে। Clear all data orders, Wishlist, cart এবং profile-এর contact/shipping তথ্য মুছে দেয়, কিন্তু account বা active login session মুছে দেয় না।
- `profile.html`-এর theme preference shared theme-এর সঙ্গে sync হয়। Profile page-এ Light/Dark বদলালে অন্য পেইজেও একই পছন্দ থাকে (`localStorage`)।
- Footer থেকে Support link সরানো হয়েছে। `login.html`-এ footer নেই; `ai.html` ও `admin-login.html`-এও আগের মতো footer যোগ করা হয়নি।
- ডিফল্ট theme Light Mode। Dark mode-এ gray লেখা যেন পড়া যায়, সে জন্য contrast classes ও fallback style ঠিক করা হয়েছে।
- `$50`-এর উপর free-shipping offer ও সংশ্লিষ্ট home-page promo সরানো হয়েছে। বিদ্যমান `$5.99` shipping fee এখন প্রতিটি non-empty cart-এ প্রযোজ্য; empty cart-এ fee `$0.00`।
- Products search input খালি করলে search filter সঙ্গে সঙ্গে clear হয় এবং full product set ফেরত আসে।
- AI logo-গুলোর SVG path `ai.svg.txt`-এর সঙ্গে মিলিয়ে দেওয়া হয়েছে। পাওয়া বানান/ব্যাকরণগত ভুল এবং broken local link-ও সংশোধন করা হয়েছে।
- Theme/menu, sample product listing, cart, wishlist, demo login, AI chat, checkout preview, order tracking এবং feedback-এর জন্য browser-only fallback যুক্ত করা হয়েছে।

- Profile sidebar-এ Affiliate option যোগ করা হয়েছে; এটি attached dashboard layout ব্যবহার করে `affiliate.html`-এ যায়। `product-detail.html`-এ Share এবং Copy link action যুক্ত হয়েছে। Order Confirmation-এর অতিরিক্ত নিচের logo/header strip সরানো হয়েছে।

## Admin Panel, Influencer ও Live Customer Care সংযোজন
- **আলাদা Admin Session (`admin-login.html` → `admin-panal.html`)**: ইমেইল `m@m.m` এবং পাসওয়ার্ড `1234` দিয়ে কোনো OTP ছাড়াই সরাসরি Admin Panel-এ লগইন করা যায় (`fiad_admin_session`)। Admin Panel-এ যাওয়া বা সেখান থেকে Logout করলে সাধারণ ইউজারের স্টোর লগইন (`fiad_user`) কখনোই মুছে যায় না—ফলে একজন টেস্টার একই ব্রাউজারে ইউজার, অ্যাফিলিয়েট/ইনফ্লুয়েন্সার ও অ্যাডমিন হিসেবে সব ফিচার পরীক্ষা করতে পারবেন।
- **Admin Sidebar পরিমার্জন**: নির্দেশনা অনুযায়ী Admin Panel থেকে `Homepage`, `AI Knowledge`, `Email Providers` এবং `Products` সেকশন বাদ দেওয়া হয়েছে। রাখা হয়েছে: `Dashboard`, `Orders`, `Affiliates & Influencer`, `Contact Messages`, `Live Customer Care`, `Support Settings`, `Feedback` এবং `Users`।
- **Contact Us → Admin Inbox (`contact.html`)**: Contact Us পেইজ থেকে পাঠানো প্রতিটি মেসেজ `localStorage` (`fiad_contact_messages`)-এ সংরক্ষিত হয়ে সরাসরি Admin Panel-এর **Contact Messages** সেকশনে যায়।
- **Index Sticky AI ও Active Customer Care (`index.html`)**: হোমপেইজের নিচে ডানদিকে ভাসমান AI চ্যাট বাটন (`ai.svg.txt` লোগোসহ) যুক্ত করা হয়েছে। ডিফল্টভাবে **Fiad AI** উত্তর দেয়; আর Admin Panel থেকে **Customer Care Active** চালু করলে পপআপেই **Live Customer Care** ট্যাব সক্রিয় হয় এবং ইউজার ও অ্যাডমিনের মধ্যে সরাসরি দ্বিমুখী মেসেজ আদান-প্রদান করা যায়।
- **Order Acceptance ও Live Sync**: ইউজার অর্ডার প্লেস করলে তা Admin Panel-এর **Orders** সেকশনে আসে। অ্যাডমিন **Accept** (অথবা Shipped / Delivered / Rejected) করলে ইউজারের `profile.html` (My Orders) এবং `order-tracking.html`-এ স্ট্যাটাস সাথে সাথে আপডেট হয়।
- **Affiliate List ও Influencer Badge + Custom Commission (`affiliate.html` ↔ `influencer.html`)**: Admin Panel-এর **Affiliates & Influencer** সেকশন থেকে অ্যাফিলিয়েট লিস্ট দেখা যায় এবং যেকোনো কাস্টম কমিশন রেট (`%`) সহ **Influencer Badge** দেওয়া বা তুলে নেওয়া যায়। ব্যাজ দেওয়া থাকলে `affiliate.html`, `profile.html` বা `earn-with-us.html` থেকে গেলে স্বয়ংক্রিয়ভাবে `influencer.html` ওপেন হয় (শেয়ার্ড নন-স্টিকি হেডার, ইউজারের নাম, Influencer ব্যাজ ও অ্যাডমিনের দেওয়া কাস্টম কমিশন `%` সহ); ব্যাজ তুলে নিলে আবার `affiliate.html`-এ ফিরে যায়।

## চালানোর পদ্ধতি
এই ফোল্ডার থেকে একটি static web server চালান, যেমন:

```bash
python3 -m http.server 8000
```

তারপর `http://localhost:8000/index.html` খুলুন। সরাসরি `file://` দিয়ে খোলার বদলে server দিয়ে চালালে সব পেইজ একই origin-এ থাকবে এবং `localStorage` ঠিকভাবে share হবে।

## সীমাবদ্ধতা ও নিরাপত্তা
সংযুক্ত ফাইলগুলোতে backend/API সরবরাহ করা হয়নি। তাই login/account, cart, wishlist, profile ও order data শুধু এই browser-এ থাকে। Registration password browser-এ hash করে রাখা হয়, কিন্তু `1122` স্থির demo OTP—এটি বাস্তব নিরাপত্তা নয়। Checkout-এ payment method কেবল demo order-এ সংরক্ষিত হয়; কোনো real payment বা real order তৈরি হয় না। Production-এ deploy করার আগে demo auth/payment-কে প্রকৃত backend/API ও secure OTP/payment provider-এর সঙ্গে যুক্ত করতে হবে।
