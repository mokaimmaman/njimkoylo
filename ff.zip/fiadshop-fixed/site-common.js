/* FIADSHOP shared frontend helpers: persistent theme, shared navigation, and a browser-only demo API. */
(function () {
  'use strict';

  const safeGet = (key, fallback = null) => {
    try {
      const value = localStorage.getItem(key);
      return value == null ? fallback : value;
    } catch (_) { return fallback; }
  };
  const safeSet = (key, value) => {
    try { localStorage.setItem(key, value); } catch (_) {}
  };
  const safeRemove = (key) => {
    try { localStorage.removeItem(key); } catch (_) {}
  };
  const readJson = (key, fallback) => {
    try {
      const raw = safeGet(key, null);
      if (raw == null) return fallback;
      const parsed = JSON.parse(raw);
      return parsed ?? fallback;
    } catch (_) { return fallback; }
  };
  const saveJson = (key, value) => safeSet(key, JSON.stringify(value));
  const joinedLabel = () => new Intl.DateTimeFormat('en', { month: 'short', year: 'numeric' }).format(new Date());

  // Capture ?ref= and ?promo= on any storefront page visit so referral/promo attribution persists.
  try {
    const entryParams = new URLSearchParams(window.location.search);
    const refParam = (entryParams.get('ref') || '').trim().toUpperCase();
    const promoParam = (entryParams.get('promo') || '').trim().toUpperCase();
    if (refParam) safeSet('fiad_ref', refParam);
    if (promoParam) safeSet('fiad_promo', promoParam);
  } catch (_) {}

  // Shared checkout/profile country options (Israel is excluded in this demo list).
  window.FiadCountries = [
    ["AF","Afghanistan"],["AL","Albania"],["DZ","Algeria"],["AD","Andorra"],["AO","Angola"],["AG","Antigua and Barbuda"],["AR","Argentina"],["AM","Armenia"],["AU","Australia"],["AT","Austria"],["AZ","Azerbaijan"],
    ["BS","Bahamas"],["BH","Bahrain"],["BD","Bangladesh"],["BB","Barbados"],["BY","Belarus"],["BE","Belgium"],["BZ","Belize"],["BJ","Benin"],["BT","Bhutan"],["BO","Bolivia"],["BA","Bosnia and Herzegovina"],["BW","Botswana"],["BR","Brazil"],["BN","Brunei"],["BG","Bulgaria"],["BF","Burkina Faso"],["BI","Burundi"],
    ["KH","Cambodia"],["CM","Cameroon"],["CA","Canada"],["CV","Cape Verde"],["CF","Central African Republic"],["TD","Chad"],["CL","Chile"],["CN","China"],["CO","Colombia"],["KM","Comoros"],["CG","Congo"],["CD","DR Congo"],["CR","Costa Rica"],["HR","Croatia"],["CU","Cuba"],["CY","Cyprus"],["CZ","Czech Republic"],
    ["DK","Denmark"],["DJ","Djibouti"],["DM","Dominica"],["DO","Dominican Republic"],
    ["EC","Ecuador"],["EG","Egypt"],["SV","El Salvador"],["GQ","Equatorial Guinea"],["ER","Eritrea"],["EE","Estonia"],["SZ","Eswatini"],["ET","Ethiopia"],
    ["FJ","Fiji"],["FI","Finland"],["FR","France"],
    ["GA","Gabon"],["GM","Gambia"],["GE","Georgia"],["DE","Germany"],["GH","Ghana"],["GR","Greece"],["GD","Grenada"],["GT","Guatemala"],["GN","Guinea"],["GW","Guinea-Bissau"],["GY","Guyana"],
    ["HT","Haiti"],["HN","Honduras"],["HU","Hungary"],
    ["IS","Iceland"],["IN","India"],["ID","Indonesia"],["IR","Iran"],["IQ","Iraq"],["IE","Ireland"],["IT","Italy"],
    ["JM","Jamaica"],["JP","Japan"],["JO","Jordan"],
    ["KZ","Kazakhstan"],["KE","Kenya"],["KI","Kiribati"],["KP","North Korea"],["KR","South Korea"],["KW","Kuwait"],["KG","Kyrgyzstan"],
    ["LA","Laos"],["LV","Latvia"],["LB","Lebanon"],["LS","Lesotho"],["LR","Liberia"],["LY","Libya"],["LI","Liechtenstein"],["LT","Lithuania"],["LU","Luxembourg"],
    ["MG","Madagascar"],["MW","Malawi"],["MY","Malaysia"],["MV","Maldives"],["ML","Mali"],["MT","Malta"],["MH","Marshall Islands"],["MR","Mauritania"],["MU","Mauritius"],["MX","Mexico"],["FM","Micronesia"],["MD","Moldova"],["MC","Monaco"],["MN","Mongolia"],["ME","Montenegro"],["MA","Morocco"],["MZ","Mozambique"],["MM","Myanmar"],
    ["NA","Namibia"],["NR","Nauru"],["NP","Nepal"],["NL","Netherlands"],["NZ","New Zealand"],["NI","Nicaragua"],["NE","Niger"],["NG","Nigeria"],["MK","North Macedonia"],["NO","Norway"],
    ["OM","Oman"],
    ["PK","Pakistan"],["PW","Palau"],["PA","Panama"],["PG","Papua New Guinea"],["PY","Paraguay"],["PE","Peru"],["PH","Philippines"],["PL","Poland"],["PT","Portugal"],
    ["QA","Qatar"],
    ["RO","Romania"],["RU","Russia"],["RW","Rwanda"],
    ["KN","Saint Kitts and Nevis"],["LC","Saint Lucia"],["VC","Saint Vincent and the Grenadines"],["WS","Samoa"],["SM","San Marino"],["ST","Sao Tome and Principe"],["SA","Saudi Arabia"],["SN","Senegal"],["RS","Serbia"],["SC","Seychelles"],["SL","Sierra Leone"],["SG","Singapore"],["SK","Slovakia"],["SI","Slovenia"],["SB","Solomon Islands"],["SO","Somalia"],["ZA","South Africa"],["SS","South Sudan"],["ES","Spain"],["LK","Sri Lanka"],["SD","Sudan"],["SR","Suriname"],["SE","Sweden"],["CH","Switzerland"],["SY","Syria"],
    ["TW","Taiwan"],["TJ","Tajikistan"],["TZ","Tanzania"],["TH","Thailand"],["TL","Timor-Leste"],["TG","Togo"],["TO","Tonga"],["TT","Trinidad and Tobago"],["TN","Tunisia"],["TR","Turkey"],["TM","Turkmenistan"],["TV","Tuvalu"],
    ["UG","Uganda"],["UA","Ukraine"],["AE","United Arab Emirates"],["GB","United Kingdom"],["US","United States"],["UY","Uruguay"],["UZ","Uzbekistan"],
    ["VU","Vanuatu"],["VA","Vatican City"],["VE","Venezuela"],["VN","Vietnam"],
    ["YE","Yemen"],
    ["ZM","Zambia"],["ZW","Zimbabwe"]
  ];

  // Respect a saved choice; otherwise start in light mode (never infer dark mode from OS settings).
  let preferredTheme = safeGet('theme') || safeGet('fiad_theme');
  if (preferredTheme !== 'dark' && preferredTheme !== 'light') preferredTheme = 'light';
  safeSet('theme', preferredTheme);
  safeSet('fiad_theme', preferredTheme);
  document.documentElement.classList.toggle('dark', preferredTheme === 'dark');

  function applyTheme(theme, persist = true) {
    const dark = theme === 'dark';
    document.documentElement.classList.toggle('dark', dark);
    if (persist) {
      safeSet('theme', dark ? 'dark' : 'light');
      safeSet('fiad_theme', dark ? 'dark' : 'light');
    }
    const button = document.getElementById('site-theme-toggle');
    const icon = document.getElementById('site-theme-icon');
    if (icon) icon.textContent = dark ? '☀️' : '🌙';
    if (button) {
      button.setAttribute('aria-pressed', String(dark));
      button.setAttribute('aria-label', dark ? 'Switch to light mode' : 'Switch to dark mode');
      button.title = dark ? 'Switch to light mode' : 'Switch to dark mode';
    }
    document.dispatchEvent(new CustomEvent('fiad:theme-changed', { detail: { theme: dark ? 'dark' : 'light' } }));
  }
  window.FiadTheme = {
    get: () => (document.documentElement.classList.contains('dark') ? 'dark' : 'light'),
    set: theme => { preferredTheme = theme === 'dark' ? 'dark' : 'light'; applyTheme(preferredTheme, true); }
  };

  function readCart() { return readJson('fiad_cart', []); }
  function saveCart(items) {
    saveJson('fiad_cart', items);
    document.dispatchEvent(new CustomEvent('fiad:cart-updated', { detail: { items } }));
    updateBadges();
  }
  function readWishlist() { return readJson('fiad_wishlist', []); }
  function saveWishlist(items) {
    saveJson('fiad_wishlist', items);
    document.dispatchEvent(new CustomEvent('fiad:wishlist-updated', { detail: { items } }));
    updateBadges();
  }

  function updateBadges() {
    const cartCount = readCart().reduce((n, item) => n + (Number(item.quantity) || 1), 0);
    const cartBadge = document.getElementById('cart-count');
    if (cartBadge) cartBadge.textContent = String(cartCount);
  }

  function toast(message, type = 'info') {
    const container = document.getElementById('toast-container') || (() => {
      const el = document.createElement('div');
      el.id = 'toast-container';
      el.className = 'fixed top-20 right-4 z-[100] space-y-2';
      document.body.appendChild(el);
      return el;
    })();
    const item = document.createElement('div');
    const tone = type === 'error' || type === 'warn' ? 'border-red-300' : 'border-gray-200';
    item.className = `bg-white dark:bg-zinc-900 text-gray-900 dark:text-gray-100 border ${tone} rounded-lg shadow-lg px-4 py-3 text-sm`;
    item.setAttribute('role', 'status');
    item.textContent = String(message ?? '');
    container.appendChild(item);
    window.setTimeout(() => item.remove(), 3200);
  }

  const demoImage = (name, c1 = '#fb923c', c2 = '#c2410c') => 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="${c1}"/><stop offset="1" stop-color="${c2}"/></linearGradient></defs><rect width="640" height="640" fill="url(#g)"/><circle cx="520" cy="130" r="150" fill="#fff" opacity=".15"/><rect x="70" y="250" width="500" height="140" rx="28" fill="#fff" opacity=".15"/><text x="320" y="310" text-anchor="middle" fill="#fff" font-family="Arial,sans-serif" font-size="32" font-weight="700">FIADSHOP</text><text x="320" y="355" text-anchor="middle" fill="#fff" font-family="Arial,sans-serif" font-size="23">${name}</text></svg>`
  );

  const demoProducts = [
    {
      id: 'demo-cotton-tee',
      aliases: ['sample-cotton-tshirt'],
      name: 'Classic Cotton T-Shirt',
      basePrice: 24.99,
      category: 'Clothing',
      description: 'A soft, comfortable everyday cotton T-shirt.',
      sku: 'FIAD-TEE-01',
      isProMode: false,
      highlights: '100% combed cotton · Breathable weave · Pre-shrunk regular fit',
      optionLabel: 'Unisex standard fit',
      bullets: [
        ['Everyday Comfort', 'Ring-spun combed cotton fabric that stays breathable in warm weather.'],
        ['Durable Collar', 'Double-stitched ribbed crew neckline built to hold shape wash after wash.'],
        ['Clean Minimal Cut', 'Tag-free interior neck label with balanced shoulder seam construction.'],
        ['Easy Care', 'Pre-shrunk finish suitable for machine cold wash and tumble dry low.'],
      ],
      specs: [
        ['Material', '100% Ring-Spun Combed Cotton'],
        ['Fabric weight', '180 GSM mid-weight jersey'],
        ['Fit', 'Regular unisex crew-neck'],
        ['Care', 'Machine wash cold, low heat dry'],
        ['SKU', 'FIAD-TEE-01'],
        ['Brand', 'FIADSHOP Essentials'],
      ],
      images: [demoImage('Classic Cotton T-Shirt', '#fb923c', '#c2410c')],
    },
    {
      id: 'demo-canvas-tote',
      aliases: ['sample-everyday-tote'],
      name: 'Everyday Canvas Tote',
      basePrice: 18.5,
      category: 'Accessories',
      description: 'A lightweight canvas tote for daily essentials.',
      sku: 'FIAD-TOTE-02',
      isProMode: false,
      highlights: 'Heavyweight cotton canvas · Reinforced handles · Inner organizer pocket',
      optionLabel: 'Natural heavyweight canvas',
      bullets: [
        ['Sturdy Construction', '12 oz woven cotton canvas engineered to carry laptops, books, and groceries.'],
        ['Reinforced Straps', 'Cross-stitched shoulder straps for comfortable all-day carry.'],
        ['Interior Pocket', 'Quick-access slip pocket keeps keys, wallet, and phone organized.'],
        ['Foldable & Reusable', 'Folds flat into backpacks or luggage when not in use.'],
      ],
      specs: [
        ['Material', '12 oz Heavyweight Cotton Canvas'],
        ['Dimensions', '38 cm × 42 cm × 10 cm'],
        ['Strap drop', '28 cm reinforced webbing'],
        ['Capacity', '15 Liters'],
        ['SKU', 'FIAD-TOTE-02'],
        ['Brand', 'FIADSHOP Carry'],
      ],
      images: [demoImage('Everyday Canvas Tote', '#38bdf8', '#2563eb')],
    },
    {
      id: 'demo-urban-watch',
      aliases: ['sample-urban-watch'],
      name: 'Urban Analog Watch',
      basePrice: 89,
      category: 'Accessories',
      description: 'A minimal analog watch with a clean, modern face.',
      sku: 'FIAD-WATCH-03',
      isProMode: false,
      highlights: 'Japanese quartz movement · Brushed steel case · 3 ATM splash resistant',
      optionLabel: '40mm brushed case',
      bullets: [
        ['Precision Quartz', 'Reliable Japanese 3-hand analog quartz movement for accurate timekeeping.'],
        ['Scratch-Resistant Glass', 'Hardened mineral crystal dial window with clean matte index markers.'],
        ['Slim Profile', 'Ultra-thin 8mm brushed stainless steel case slips neatly under cuffs.'],
        ['Quick-Release Strap', 'Interchangeable 20mm strap with stainless buckle closure.'],
      ],
      specs: [
        ['Case material', '316L Brushed Stainless Steel'],
        ['Case diameter', '40 mm (8 mm thickness)'],
        ['Movement', 'Japanese Quartz 3-Hand'],
        ['Water resistance', '3 ATM (daily splash resistant)'],
        ['SKU', 'FIAD-WATCH-03'],
        ['Brand', 'FIADSHOP Studio'],
      ],
      images: [demoImage('Urban Analog Watch', '#a78bfa', '#6d28d9')],
    },
    {
      id: 'demo-mini-speaker',
      aliases: ['sample-mini-speaker'],
      name: 'Portable Mini Speaker',
      basePrice: 39.99,
      category: 'Electronics',
      description: 'A compact speaker with clear sound for everyday listening.',
      sku: 'FIAD-SPEAKER-04',
      isProMode: false,
      highlights: 'Bluetooth 5.3 wireless · 10-hour battery · USB-C fast charging',
      optionLabel: 'Matte charcoal edition',
      bullets: [
        ['Crisp 360° Audio', 'Custom full-range neodymium driver with passive bass radiator.'],
        ['All-Day Playback', 'Rechargeable battery delivers up to 10 hours of continuous listening.'],
        ['Pocket-Friendly Build', 'Compact anodized shell with braided carry loop for travel and desks.'],
        ['Instant Pairing', 'Bluetooth 5.3 wireless connection plus built-in microphone for calls.'],
      ],
      specs: [
        ['Connectivity', 'Bluetooth 5.3 (10m range)'],
        ['Output power', '5W RMS full-range driver + passive radiator'],
        ['Battery life', 'Up to 10 hours · USB-C charging'],
        ['Weight', '185 g'],
        ['SKU', 'FIAD-SPEAKER-04'],
        ['Brand', 'FIADSHOP Audio'],
      ],
      images: [demoImage('Portable Mini Speaker', '#34d399', '#059669')],
    },
  ];

  const legacyKnifeProduct = {
    id: '575148873_BD-2638597698',
    aliases: [],
    name: 'Plastic Training Knife with Nylon Handle & TPE Blade, Includes Sheath, Safe for Military Training, Cosplay, Halloween Props',
    basePrice: 110,
    category: 'Sports & Outdoors · Camping & Hiking',
    description: 'Training Soft Knife — Realistic & Durable Simulation Tool',
    sku: '575148873_BD-2638597698',
    isProMode: false,
    highlights: 'Soft TPE blade · Nylon handle · Sheath included',
    optionLabel: 'Standard item',
    bullets: [
      ['Safe & Non-Harmful', 'Designed for realistic training and cosplay, for simulated combat use.'],
      ['Ergonomic Grip Handle', 'Durable nylon handle with ringed grooves for a non-slip, comfortable hold.'],
      ['Flexible TPE Blade', 'Soft TPE plastic construction, bend-resistant, with detailed serrations.'],
      ['Quick-Draw Sheath', 'Includes a quick-release buckle for drawing and returning the knife.'],
    ],
    specs: [
      ['Handle material', 'Nylon'],
      ['Blade material', 'TPE (soft plastic)'],
      ['Total length', '30.5 cm / 12 inch'],
      ['Width', '5.5 cm / 2.16 inch'],
      ['Height', '4.5 cm / 1.77 inch'],
      ['Weight', '88 g'],
      ['Brand', 'No Brand'],
      ['Suggested use', 'Tactical training, airsoft and survival games, cosplay, film props, costume parties and collection'],
    ],
    images: [],
  };

  function findCatalogProduct(rawId) {
    const id = String(rawId || '').trim();
    if (!id) return null;
    if (id === legacyKnifeProduct.id) return legacyKnifeProduct;
    return demoProducts.find(p => p.id === id || (Array.isArray(p.aliases) && p.aliases.includes(id))) || null;
  }

  function normalizeCartProduct(product, quantity = 1, variant = null) {
    const id = String(product.id ?? product.productId ?? `item-${Date.now()}`);
    const price = Number(product.price ?? product.basePrice ?? product.unitPrice ?? 0);
    const originalPrice = Number(product.originalPrice ?? product.basePrice ?? price);
    const productDiscountPct = Number(product.productDiscountPct || 0);
    const refCode = product.refCode ? String(product.refCode).trim().toUpperCase() : undefined;
    const image = product.image ?? product.image_url ?? product.images?.[0] ?? product.imageUrl ?? '';
    const key = variant ? `${id}:${JSON.stringify(variant)}` : id;
    return {
      _key: key,
      id,
      name: String(product.name || 'Product'),
      price,
      originalPrice,
      productDiscountPct: productDiscountPct > 0 ? productDiscountPct : undefined,
      refCode,
      image,
      image_url: image,
      quantity: Number(quantity) || 1,
      variant: variant || undefined,
    };
  }
  const cart = {
    get: readCart,
    add(product, quantity = 1, variant = null) {
      const item = normalizeCartProduct(product, quantity, variant);
      const items = readCart();
      const existing = items.find(i => String(i._key ?? i.id) === item._key);
      if (existing) {
        existing.quantity = (Number(existing.quantity) || 0) + item.quantity;
        existing.price = item.price;
        if (item.originalPrice) existing.originalPrice = item.originalPrice;
        if (item.productDiscountPct) existing.productDiscountPct = item.productDiscountPct;
        if (item.refCode) existing.refCode = item.refCode;
      } else {
        items.push(item);
      }
      saveCart(items);
      toast(`${item.name} added to your cart.`, 'success');
      return items;
    },
    updateQty(key, quantity) {
      const items = readCart();
      const item = items.find(i => String(i._key ?? i.id) === String(key));
      if (!item) return items;
      if (Number(quantity) <= 0) return this.remove(key);
      item.quantity = Number(quantity);
      saveCart(items);
      return items;
    },
    remove(key) {
      const items = readCart().filter(i => String(i._key ?? i.id) !== String(key));
      saveCart(items);
      return items;
    },
    clear() { saveCart([]); },
    emit() { document.dispatchEvent(new CustomEvent('fiad:cart-updated', { detail: { items: readCart() } })); updateBadges(); },
  };
  const wishlist = {
    get: readWishlist,
    clear() { saveWishlist([]); },
    has(id) { return readWishlist().some(item => String(item.id) === String(id)); },
    toggle(product) {
      const items = readWishlist();
      const id = String(product.id ?? product.productId);
      const index = items.findIndex(item => String(item.id) === id);
      if (index >= 0) items.splice(index, 1);
      else items.push({ id, name: product.name || 'Product', price: Number(product.price ?? product.basePrice ?? 0), image_url: product.image_url || product.images?.[0] || '' });
      saveWishlist(items);
      toast(index >= 0 ? 'Removed from your wishlist.' : 'Saved to your wishlist.', 'success');
      return index < 0;
    },
  };

  function getUser() { return readJson('fiad_user', null); }
  function emailKey(email) { return String(email || '').trim().toLowerCase(); }
  function readAccounts() { return readJson('fiad_accounts', {}); }
  function saveAccounts(accounts) { saveJson('fiad_accounts', accounts); }
  const demoOrders = () => readJson('fiad_orders', []);
  const saveOrders = (orders) => saveJson('fiad_orders', orders);

  // Cleanly read personal promo code regardless of whether stored as raw string or JSON string
  function readPersonalPromoCode() {
    const raw = safeGet('fiad_affiliate_personal_code', '');
    if (!raw) return '';
    try {
      const parsed = JSON.parse(raw);
      return String(parsed || '').trim().toUpperCase();
    } catch (_) {
      return String(raw).replace(/^"+|"+$/g, '').trim().toUpperCase();
    }
  }
  function writePersonalPromoCode(code) {
    const clean = String(code || '').trim().toUpperCase();
    if (!clean) safeRemove('fiad_affiliate_personal_code');
    else saveJson('fiad_affiliate_personal_code', clean);
  }

  // ==================== AFFILIATE & INFLUENCER STATE + LEDGER ====================
  const SEED_REFERRED_ORDERS = [
    { orderNumber: 'FIAD-8821', createdAt: '2025-02-18T10:42:00', total: 124.00, status: 'DELIVERED', seed: true },
    { orderNumber: 'FIAD-8790', createdAt: '2025-02-17T15:15:00', total: 58.50, status: 'SHIPPED', seed: true },
    { orderNumber: 'FIAD-8755', createdAt: '2025-02-16T09:04:00', total: 210.00, status: 'PAID', seed: true },
  ];

  const SEED_WITHDRAWALS = [
    { id: 'wd-seed-1', date: '2/10/2025', amount: 200.00, method: 'USDT_TRC20', status: 'PAID', seed: true },
    { id: 'wd-seed-2', date: '2/3/2025', amount: 150.00, method: 'PAYPAL', status: 'APPROVED', seed: true },
    { id: 'wd-seed-3', date: '1/28/2025', amount: 75.00, method: 'BTC', status: 'PENDING', seed: true },
  ];

  const DEFAULT_AFFILIATE_STATE = {
    id: 'aff-primary',
    isInfluencer: false,
    type: 'REGULAR',
    level: 'SILVER',
    status: 'ACTIVE',
    commissionRate: 12,
    regularCommissionRate: 12,
    promoCodeLocked: false,
    baseSales: 47,
    baseEarned: 1284.50,
    baseBalance: 342.75,
    updatedAt: null,
  };

  function resolveAffiliateIdentity() {
    const activeUser = getUser();
    const profile = readJson('fiad_profile', null);
    if (activeUser && activeUser.email) {
      return {
        name: (profile && emailKey(profile.email) === emailKey(activeUser.email) && profile.name) || activeUser.name || activeUser.email.split('@')[0],
        email: activeUser.email,
      };
    }
    const accounts = readAccounts();
    const firstKey = Object.keys(accounts)[0];
    if (firstKey && accounts[firstKey]) {
      const acc = accounts[firstKey];
      return {
        name: acc.name || acc.profile?.name || acc.email.split('@')[0],
        email: acc.email,
      };
    }
    if (profile && profile.email) {
      return {
        name: profile.name || profile.email.split('@')[0],
        email: profile.email,
      };
    }
    return { name: 'Member', email: 'member@fiad.shop' };
  }

  function readWithdrawalsRaw() {
    const saved = readJson('fiad_affiliate_withdrawals', null);
    if (Array.isArray(saved)) return saved;
    return SEED_WITHDRAWALS.map(w => ({ ...w }));
  }

  function readRealReferredOrders(promoCode) {
    const orders = demoOrders();
    const cleanPromo = String(promoCode || '').trim().toUpperCase();
    return (Array.isArray(orders) ? orders : []).filter(o => {
      if (o.isAffiliateOrder) return true;
      if (cleanPromo && (String(o.referredByCode || '').toUpperCase() === cleanPromo || String(o.promoCode || '').toUpperCase() === cleanPromo)) return true;
      return false;
    });
  }

  const FiadAffiliate = {
    getState() {
      const saved = readJson('fiad_affiliate_state', {});
      const state = Object.assign({}, DEFAULT_AFFILIATE_STATE, saved || {});
      const identity = resolveAffiliateIdentity();
      const promoCode = readPersonalPromoCode();
      state.isInfluencer = Boolean(state.isInfluencer || state.type === 'INFLUENCER');
      state.type = state.isInfluencer ? 'INFLUENCER' : 'REGULAR';
      const rate = Number(state.commissionRate);
      state.commissionRate = Number.isFinite(rate) && rate > 0 ? rate : 12;
      state.userName = identity.name;
      state.userEmail = identity.email;
      state.promoCode = promoCode;
      if (promoCode && saved?.promoCodeLocked === undefined) {
        state.promoCodeLocked = true;
      }

      // Compute live sales, earnings, and available balance from real orders + withdrawals
      const baseSales = Number(state.baseSales ?? 47);
      const baseEarned = Number(state.baseEarned ?? 1284.50);
      const baseBalance = Number(state.baseBalance ?? 342.75);

      const realOrders = readRealReferredOrders(promoCode);
      const validOrders = realOrders.filter(o => !['CANCELLED', 'REJECTED'].includes(String(o.status || '').toUpperCase()));
      const extraEarned = validOrders.reduce((sum, o) => sum + (Number(o.affiliateCommission) || 0), 0);

      const withdrawals = readWithdrawalsRaw();
      const userWithdrawals = withdrawals.filter(w => !w.seed && String(w.status || '').toUpperCase() !== 'REJECTED');
      const withdrawnSum = userWithdrawals.reduce((sum, w) => sum + (Number(w.amount) || 0), 0);

      state.totalSales = baseSales + validOrders.length;
      state.totalEarned = Math.round((baseEarned + extraEarned) * 100) / 100;
      state.balance = Math.max(0, Math.round((baseBalance + extraEarned - withdrawnSum) * 100) / 100);
      return state;
    },
    updateState(patch = {}) {
      const current = this.getState();
      const next = Object.assign({}, DEFAULT_AFFILIATE_STATE, readJson('fiad_affiliate_state', {}), patch);
      if ('isInfluencer' in patch) {
        next.isInfluencer = Boolean(patch.isInfluencer);
        next.type = next.isInfluencer ? 'INFLUENCER' : 'REGULAR';
      } else if ('type' in patch) {
        next.isInfluencer = patch.type === 'INFLUENCER';
        next.type = next.isInfluencer ? 'INFLUENCER' : 'REGULAR';
      }
      if ('commissionRate' in patch && patch.commissionRate != null && patch.commissionRate !== '') {
        const parsedRate = Number(patch.commissionRate);
        if (Number.isFinite(parsedRate) && parsedRate > 0) {
          next.commissionRate = Math.min(90, Math.max(1, parsedRate));
        }
      } else if (patch.isInfluencer === false && !('commissionRate' in patch)) {
        next.commissionRate = Number(current.regularCommissionRate) || 12;
      }
      if ('promoCode' in patch) {
        writePersonalPromoCode(patch.promoCode);
      }
      delete next.userName;
      delete next.userEmail;
      delete next.promoCode;
      delete next.totalSales;
      delete next.totalEarned;
      delete next.balance;
      next.updatedAt = new Date().toISOString();
      saveJson('fiad_affiliate_state', next);
      document.dispatchEvent(new CustomEvent('fiad:affiliate-changed', { detail: this.getState() }));
      updateAffiliateLinks();
      return this.getState();
    },
    getReferredOrders() {
      const state = this.getState();
      const real = readRealReferredOrders(state.promoCode).map(o => ({
        orderNumber: String(o.orderNumber || o.id || '').replace(/^#/, ''),
        createdAt: o.createdAt || o.date || new Date().toISOString(),
        total: Number(o.total || 0),
        commission: Number(o.affiliateCommission || 0),
        status: String(o.status || 'PENDING').toUpperCase(),
        seed: false,
      }));
      return [...real, ...SEED_REFERRED_ORDERS];
    },
    getWithdrawals() {
      return readWithdrawalsRaw();
    },
    requestWithdrawal(amount, method = 'USDT_TRC20') {
      const state = this.getState();
      if ((state.status || 'ACTIVE') !== 'ACTIVE') {
        throw new Error('Your affiliate account is currently suspended.');
      }
      const num = Math.round(Number(amount || 0) * 100) / 100;
      if (!Number.isFinite(num) || num < 10) {
        throw new Error('Enter a valid withdrawal amount (min $10).');
      }
      if (num > state.balance) {
        throw new Error(`Amount exceeds your available balance ($${state.balance.toFixed(2)}).`);
      }
      const list = readWithdrawalsRaw();
      const entry = {
        id: `WD-${Date.now().toString().slice(-6)}`,
        date: new Date().toLocaleDateString('en-US'),
        createdAt: new Date().toISOString(),
        amount: num,
        method: String(method || 'USDT_TRC20').toUpperCase(),
        status: 'PENDING',
        seed: false,
      };
      const updated = [entry, ...list];
      saveJson('fiad_affiliate_withdrawals', updated);
      // Touch affiliate state timestamp so storage/custom listeners sync across open tabs
      const rawState = readJson('fiad_affiliate_state', {}) || {};
      rawState.updatedAt = new Date().toISOString();
      saveJson('fiad_affiliate_state', rawState);
      document.dispatchEvent(new CustomEvent('fiad:affiliate-changed', { detail: this.getState() }));
      return entry;
    },
    getDashboardHref() {
      return this.getState().isInfluencer ? 'influencer.html' : 'affiliate.html';
    },
  };
  window.FiadAffiliate = FiadAffiliate;

  // ==================== PROMO & REFERRAL EVALUATION ENGINE ====================
  const STORE_PROMO_CODES = {
    FIAD10: { pct: 10, label: 'Store promo (10% off)' },
    WELCOME10: { pct: 10, label: 'Welcome discount (10% off)' },
    SAVE5: { pct: 5, label: 'Promo discount (5% off)' },
    FIAD20: { pct: 20, label: 'Special promo (20% off)' },
  };

  function countPriorReferredOrders(buyerEmail, affCode) {
    const cleanEmail = emailKey(buyerEmail);
    const cleanCode = String(affCode || '').trim().toUpperCase();
    return demoOrders().filter(o => {
      if (['CANCELLED', 'REJECTED'].includes(String(o.status || '').toUpperCase())) return false;
      const sameCode = cleanCode && (String(o.referredByCode || '').toUpperCase() === cleanCode || String(o.promoCode || '').toUpperCase() === cleanCode);
      if (!sameCode) return false;
      if (cleanEmail) return emailKey(o.email || o.shippingAddress?.email || '') === cleanEmail;
      return true;
    }).length;
  }

  const FiadPromo = {
    evaluate(rawCode, items = [], buyerEmail = '') {
      const list = Array.isArray(items) ? items : [];
      const subtotal = list.reduce((s, i) => s + (Number(i.price) || 0) * (Number(i.quantity) || 1), 0);
      const code = String(rawCode || '').trim().toUpperCase();

      // Subtotal of items that do NOT already have a product-link discount baked into item.price
      const eligibleSubtotal = list.reduce((s, i) => {
        if (Number(i.productDiscountPct) > 0) return s;
        return s + (Number(i.price) || 0) * (Number(i.quantity) || 1);
      }, 0);

      if (!code) {
        return { valid: false, code: '', discountPct: 0, discountAmount: 0, subtotal, discountedSubtotal: subtotal, isAffiliateCode: false, message: '' };
      }

      const aff = FiadAffiliate.getState();
      if (aff.promoCode && code === aff.promoCode.toUpperCase()) {
        if ((aff.status || 'ACTIVE') !== 'ACTIVE') {
          return { valid: false, code, discountPct: 0, discountAmount: 0, subtotal, discountedSubtotal: subtotal, isAffiliateCode: true, message: 'This referral code is currently inactive.' };
        }
        const resolvedEmail = buyerEmail || getUser()?.email || '';
        const priorCount = countPriorReferredOrders(resolvedEmail, code);
        let pct = 0;
        let note = '';
        if (priorCount === 0) {
          pct = 10;
          note = 'First-order referral discount (10% off)';
        } else if (priorCount < 10) {
          pct = 5;
          note = `Referral benefit #${priorCount + 1} of 10 (5% off)`;
        } else {
          pct = 0;
          note = 'Referral code recognized (10-order buyer discount limit reached)';
        }
        const discountAmount = eligibleSubtotal > 0 && pct > 0
          ? Math.round(eligibleSubtotal * (pct / 100) * 100) / 100
          : 0;
        const discountedSubtotal = Math.max(0, Math.round((subtotal - discountAmount) * 100) / 100);
        return {
          valid: true,
          code,
          discountPct: pct,
          discountAmount,
          subtotal,
          discountedSubtotal,
          isAffiliateCode: true,
          message: discountAmount > 0
            ? `${note}: -$${discountAmount.toFixed(2)} saved!`
            : (eligibleSubtotal === 0 && subtotal > 0 ? 'Product referral discount is already applied to your item price.' : note),
        };
      }

      if (STORE_PROMO_CODES[code]) {
        const pct = STORE_PROMO_CODES[code].pct;
        const discountAmount = eligibleSubtotal > 0
          ? Math.round(eligibleSubtotal * (pct / 100) * 100) / 100
          : 0;
        const discountedSubtotal = Math.max(0, Math.round((subtotal - discountAmount) * 100) / 100);
        return {
          valid: true,
          code,
          discountPct: pct,
          discountAmount,
          subtotal,
          discountedSubtotal,
          isAffiliateCode: false,
          message: `${STORE_PROMO_CODES[code].label}: -$${discountAmount.toFixed(2)} saved!`,
        };
      }

      return {
        valid: false,
        code,
        discountPct: 0,
        discountAmount: 0,
        subtotal,
        discountedSubtotal: subtotal,
        isAffiliateCode: false,
        message: 'Invalid promo or referral code.',
      };
    },
  };
  window.FiadPromo = FiadPromo;

  // ==================== CONTACT MESSAGES ====================
  const FiadMessages = {
    getAll() {
      const list = readJson('fiad_contact_messages', []);
      return Array.isArray(list) ? list : [];
    },
    saveAll(list) {
      saveJson('fiad_contact_messages', Array.isArray(list) ? list : []);
      document.dispatchEvent(new CustomEvent('fiad:messages-changed'));
    },
    submit({ email, name = '', message }) {
      const cleanEmail = String(email || '').trim();
      const cleanMsg = String(message || '').trim();
      if (!cleanEmail || !cleanMsg) throw new Error('Email and message are required.');
      const activeUser = getUser();
      const resolvedName = String(name || activeUser?.name || cleanEmail.split('@')[0] || 'Visitor').trim();
      const item = {
        id: `MSG-${Date.now().toString().slice(-7)}`,
        name: resolvedName,
        email: cleanEmail,
        message: cleanMsg,
        status: 'UNREAD',
        adminNote: '',
        createdAt: new Date().toISOString(),
      };
      this.saveAll([item, ...this.getAll()]);
      return item;
    },
    update(id, patch = {}) {
      const list = this.getAll();
      const idx = list.findIndex(m => m.id === id);
      if (idx < 0) return null;
      list[idx] = Object.assign({}, list[idx], patch, { updatedAt: new Date().toISOString() });
      this.saveAll(list);
      return list[idx];
    },
    remove(id) {
      this.saveAll(this.getAll().filter(m => m.id !== id));
    },
    unreadCount() {
      return this.getAll().filter(m => m.status === 'UNREAD').length;
    }
  };
  window.FiadMessages = FiadMessages;

  // ==================== LIVE CUSTOMER CARE & SUPPORT SETTINGS ====================
  const DEFAULT_SUPPORT_SETTINGS = {
    isLiveEnabled: false,
    offlineMessage: 'Live customer care is currently offline. You can chat with Fiad AI anytime or send us a message on the Contact page.',
  };

  function getVisitorSessionKey() {
    const user = getUser();
    if (user?.email) return `user:${emailKey(user.email)}`;
    let guestId = safeGet('fiad_guest_support_id', '');
    if (!guestId) {
      guestId = 'guest_' + Math.random().toString(36).slice(2, 10);
      safeSet('fiad_guest_support_id', guestId);
    }
    return `guest:${guestId}`;
  }

  const FiadSupport = {
    getSettings() {
      return Object.assign({}, DEFAULT_SUPPORT_SETTINGS, readJson('fiad_support_settings', {}) || {});
    },
    saveSettings(patch = {}) {
      const next = Object.assign({}, this.getSettings(), patch, { updatedAt: new Date().toISOString() });
      next.isLiveEnabled = Boolean(next.isLiveEnabled);
      saveJson('fiad_support_settings', next);
      document.dispatchEvent(new CustomEvent('fiad:support-changed', { detail: next }));
      return next;
    },
    getSessions() {
      const list = readJson('fiad_support_sessions', []);
      return Array.isArray(list) ? list : [];
    },
    saveSessions(list) {
      saveJson('fiad_support_sessions', Array.isArray(list) ? list : []);
      document.dispatchEvent(new CustomEvent('fiad:support-sessions-changed'));
    },
    getCurrentUserSession() {
      const key = getVisitorSessionKey();
      return this.getSessions().find(s => s.visitorKey === key) || null;
    },
    sendUserMessage(text, customEmail = '') {
      const clean = String(text || '').trim();
      if (!clean) throw new Error('Enter a message.');
      const user = getUser();
      const key = getVisitorSessionKey();
      const sessions = this.getSessions();
      let session = sessions.find(s => s.visitorKey === key);
      const now = new Date().toISOString();
      const userName = user?.name || (customEmail ? customEmail.split('@')[0] : 'Store Visitor');
      const userEmail = user?.email || String(customEmail || '').trim() || 'Guest Visitor';
      if (!session) {
        session = {
          id: `CS-${Date.now().toString().slice(-6)}`,
          visitorKey: key,
          userName,
          email: userEmail,
          status: 'OPEN',
          unreadForAdmin: 0,
          unreadForUser: 0,
          createdAt: now,
          updatedAt: now,
          messages: [],
        };
        sessions.unshift(session);
      } else {
        session.status = 'OPEN';
        if (user?.name) session.userName = user.name;
        if (user?.email) session.email = user.email;
        else if (customEmail) session.email = String(customEmail).trim();
      }
      session.messages = Array.isArray(session.messages) ? session.messages : [];
      session.messages.push({
        id: `m_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        sender: 'user',
        senderName: session.userName,
        message: clean,
        createdAt: now,
      });
      session.unreadForAdmin = (Number(session.unreadForAdmin) || 0) + 1;
      session.updatedAt = now;
      sessions.sort((a, b) => new Date(b.updatedAt || 0) - new Date(a.updatedAt || 0));
      this.saveSessions(sessions);
      return session;
    },
    sendAdminMessage(sessionId, text) {
      const clean = String(text || '').trim();
      if (!clean) throw new Error('Enter a reply.');
      const sessions = this.getSessions();
      const session = sessions.find(s => s.id === sessionId);
      if (!session) throw new Error('Support session not found.');
      const now = new Date().toISOString();
      session.messages = Array.isArray(session.messages) ? session.messages : [];
      session.messages.push({
        id: `m_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        sender: 'admin',
        senderName: 'Customer Care',
        message: clean,
        createdAt: now,
      });
      session.status = 'OPEN';
      session.unreadForAdmin = 0;
      session.unreadForUser = (Number(session.unreadForUser) || 0) + 1;
      session.updatedAt = now;
      sessions.sort((a, b) => new Date(b.updatedAt || 0) - new Date(a.updatedAt || 0));
      this.saveSessions(sessions);
      return session;
    },
    setSessionStatus(sessionId, status) {
      const sessions = this.getSessions();
      const session = sessions.find(s => s.id === sessionId);
      if (!session) return null;
      session.status = status;
      session.updatedAt = new Date().toISOString();
      this.saveSessions(sessions);
      return session;
    },
    markReadByAdmin(sessionId) {
      const sessions = this.getSessions();
      const session = sessions.find(s => s.id === sessionId);
      if (session && session.unreadForAdmin) {
        session.unreadForAdmin = 0;
        this.saveSessions(sessions);
      }
    },
    markReadByUser() {
      const key = getVisitorSessionKey();
      const sessions = this.getSessions();
      const session = sessions.find(s => s.visitorKey === key);
      if (session && session.unreadForUser) {
        session.unreadForUser = 0;
        this.saveSessions(sessions);
      }
    },
    adminUnreadCount() {
      return this.getSessions().reduce((sum, s) => sum + (Number(s.unreadForAdmin) || 0), 0);
    }
  };
  window.FiadSupport = FiadSupport;

  // ==================== SEPARATE ADMIN SESSION ====================
  const FiadAdminAuth = {
    getAdmin() {
      const session = readJson('fiad_admin_session', null);
      if (session && emailKey(session.email) === 'm@m.m') return session;
      return null;
    },
    isLoggedIn() {
      return Boolean(this.getAdmin());
    },
    login(email, password) {
      const cleanEmail = emailKey(email);
      const cleanPass = String(password ?? '');
      if (!cleanEmail || !cleanPass) {
        throw new Error('Enter admin email and password.');
      }
      if (cleanEmail !== 'm@m.m' || cleanPass !== '1234') {
        throw new Error('Invalid admin email or password.');
      }
      const session = {
        email: 'm@m.m',
        name: 'Admin',
        loggedInAt: new Date().toISOString(),
      };
      saveJson('fiad_admin_session', session);
      return session;
    },
    logout() {
      safeRemove('fiad_admin_session');
    }
  };
  window.FiadAdminAuth = FiadAdminAuth;

  // ==================== ORDERS, FEEDBACK & DEMO API ====================
  function normalizeFeedbackCategory(raw) {
    const up = String(raw || '').trim().toUpperCase();
    if (up === 'SOFTWARE_BUG' || up === 'BUG_SOFTWARE') return 'BUG_SOFTWARE';
    if (up === 'SECURITY_BUG' || up === 'BUG_SECURITY') return 'BUG_SECURITY';
    if (up === 'SUGGESTION' || up === 'PRODUCT_REQUEST' || up === 'FEATURE') return 'SUGGESTION';
    return up || 'SUGGESTION';
  }

  function mapOrderForApi(order) {
    return {
      orderNumber: order.orderNumber || order.id,
      id: order.id || order.orderNumber,
      subtotal: Number(order.subtotal ?? order.total ?? 0),
      discountAmount: Number(order.discountAmount || 0),
      promoCode: order.promoCode || '',
      total: Number(order.total || 0),
      status: order.status || 'PENDING',
      createdAt: order.createdAt || order.date || new Date().toISOString(),
      items: (order.items || []).map(item => ({
        name: item.name,
        quantity: Number(item.quantity || 1),
        unitPrice: Number(item.price || item.unitPrice || 0),
        lineTotal: Number(item.price || item.unitPrice || 0) * Number(item.quantity || 1),
        image_url: item.image_url || item.image || '',
      })),
      shippingAddress: order.shippingAddress || {},
      trackingNumber: order.trackingNumber || '',
      trackingCarrier: order.trackingCarrier || '',
      paymentMethod: order.paymentMethod || '',
      email: order.email || order.shippingAddress?.email || '',
    };
  }

  const api = {
    async get(path) {
      const url = new URL(String(path), location.href);
      const pathname = url.pathname;
      if (pathname.endsWith('/settings/homepage')) return { items: demoProducts.slice(0, 4) };
      if (pathname.endsWith('/products')) {
        const limit = Number(url.searchParams.get('limit')) || demoProducts.length;
        return { items: demoProducts.slice(0, limit) };
      }
      const prodMatch = pathname.match(/\/products\/([^/]+)$/);
      if (prodMatch) {
        const found = findCatalogProduct(decodeURIComponent(prodMatch[1]));
        if (!found) throw new Error('Product not found in catalog.');
        return { product: found };
      }
      if (pathname.endsWith('/orders/mine')) return { orders: demoOrders().map(mapOrderForApi) };
      const orderMatch = pathname.match(/\/orders\/([^/]+)\/track$/);
      if (orderMatch) {
        const rawId = decodeURIComponent(orderMatch[1]).trim().replace(/^#/, '');
        const stripPrefix = s => String(s || '').trim().replace(/^#/, '').replace(/^(FIAD-|FS-)/i, '').toLowerCase();
        const order = demoOrders().find(o => {
          const full = String(o.orderNumber || o.id || '').trim().toLowerCase();
          return full === rawId.toLowerCase() || stripPrefix(full) === stripPrefix(rawId);
        });
        if (!order) throw new Error('This demo order was not found in this browser.');
        return { order: mapOrderForApi(order) };
      }
      throw new Error('This action is not available in the browser-only demo.');
    },
    async post(path, payload = {}) {
      const pathname = new URL(String(path), location.href).pathname;
      if (pathname.endsWith('/orders/create')) {
        const items = Array.isArray(payload.checkoutItems) ? payload.checkoutItems : readCart();
        if (!items.length) throw new Error('Your cart is empty.');
        const activeUser = getUser();
        const buyerEmail = payload.shippingAddress?.email || activeUser?.email || '';
        const subtotal = Math.round(items.reduce((sum, item) => sum + Number(item.price || 0) * Number(item.quantity || 1), 0) * 100) / 100;

        const submittedPromo = String(payload.promoCode || '').trim().toUpperCase();
        const submittedRef = String(payload.ref || safeGet('fiad_ref', '') || '').trim().toUpperCase();
        const codeToEvaluate = submittedPromo || submittedRef;

        if (submittedPromo) {
          const check = FiadPromo.evaluate(submittedPromo, items, buyerEmail);
          if (!check.valid) throw new Error(check.message || 'Invalid promo code.');
        }

        const promoEval = codeToEvaluate
          ? FiadPromo.evaluate(codeToEvaluate, items, buyerEmail)
          : { valid: false, discountPct: 0, discountAmount: 0, discountedSubtotal: subtotal, isAffiliateCode: false, code: '' };

        const discountAmount = promoEval.valid ? Number(promoEval.discountAmount || 0) : 0;
        const discountedSubtotal = Math.max(0, Math.round((subtotal - discountAmount) * 100) / 100);
        const shipping = subtotal > 0 ? 5.99 : 0;
        const total = Math.round((discountedSubtotal + shipping) * 100) / 100;

        // Calculate affiliate / influencer commission if referred
        const aff = FiadAffiliate.getState();
        const affCode = (aff.promoCode || '').toUpperCase();
        const hasItemRef = items.some(i => affCode && String(i.refCode || '').toUpperCase() === affCode);
        const isReferred = Boolean(
          (aff.status || 'ACTIVE') === 'ACTIVE' &&
          affCode &&
          (promoEval.isAffiliateCode || submittedRef === affCode || hasItemRef)
        );

        let affiliateCommission = 0;
        if (isReferred) {
          items.forEach(item => {
            const qty = Number(item.quantity) || 1;
            const linePrice = Number(item.price || 0) * qty;
            const origBase = Number(item.originalPrice || item.price || 0) * qty;
            if (Number(item.productDiscountPct) > 0) {
              const keepPct = Math.max(0, Number(aff.commissionRate || 12) - Number(item.productDiscountPct));
              affiliateCommission += origBase * (keepPct / 100);
            } else if (promoEval.isAffiliateCode && promoEval.discountPct > 0) {
              const netItem = linePrice * (1 - promoEval.discountPct / 100);
              const keepPct = aff.isInfluencer
                ? Math.max(5, Number(aff.commissionRate || 12) - promoEval.discountPct)
                : 5;
              affiliateCommission += netItem * (keepPct / 100);
            } else {
              affiliateCommission += linePrice * (Number(aff.commissionRate || 12) / 100);
            }
          });
          affiliateCommission = Math.round(affiliateCommission * 100) / 100;
        }

        const nowIso = new Date().toISOString();
        const code = `FS-${Date.now().toString().slice(-8)}`;
        const order = {
          orderNumber: code,
          id: code,
          subtotal,
          discountAmount,
          promoCode: promoEval.valid ? promoEval.code : (submittedPromo || ''),
          referredByCode: isReferred ? affCode : '',
          isAffiliateOrder: isReferred,
          affiliateCommission,
          shippingAmount: shipping,
          total,
          status: 'PENDING',
          demo: true,
          createdAt: nowIso,
          date: nowIso,
          email: buyerEmail,
          customerName: payload.shippingAddress?.fullName || payload.shippingAddress?.name || activeUser?.name || '',
          paymentMethod: payload.paymentMethod || '',
          items: items.map(item => ({ ...item })),
          shippingAddress: payload.shippingAddress || {},
        };
        saveOrders([order, ...demoOrders()]);
        saveJson('fiad_last_order', {
          orderNumber: order.orderNumber,
          subtotal: order.subtotal,
          discountAmount: order.discountAmount,
          promoCode: order.promoCode,
          total: order.total,
          email: order.email,
        });
        safeRemove('fiad_promo');
        if (isReferred) {
          document.dispatchEvent(new CustomEvent('fiad:affiliate-changed', { detail: FiadAffiliate.getState() }));
        }
        return { order: mapOrderForApi(order), demo: true };
      }
      if (pathname.endsWith('/contact')) {
        const msg = FiadMessages.submit(payload);
        return { message: msg, demo: true };
      }
      if (pathname.endsWith('/feedback')) {
        const entries = readJson('fiad_feedback', []);
        const activeUser = getUser();
        const normalizedCategory = normalizeFeedbackCategory(payload.category || payload.type);
        const entry = {
          ...payload,
          type: payload.type || normalizedCategory,
          category: normalizedCategory,
          id: `FB-${Date.now().toString().slice(-7)}`,
          userEmail: activeUser?.email || payload.guestEmail || '',
          userName: activeUser?.name || '',
          status: 'PENDING',
          createdAt: new Date().toISOString(),
        };
        saveJson('fiad_feedback', [entry, ...entries]);
        return { submission: entry, demo: true };
      }
      if (pathname.endsWith('/ai/chat')) {
        const message = String(payload.message || '').toLowerCase();
        let answer = 'This is a browser-only demo, so I cannot look up live account or order records. For store policies and product information, please check the relevant page or contact support.';
        if (/ship|deliver/.test(message)) answer = 'Shipping time depends on the destination and selected shipping method. See the FAQ page for the current shipping options and estimated delivery windows.';
        else if (/return|refund/.test(message)) answer = 'Please review the Returns section in our FAQ and Terms pages. If you have an order-specific issue, contact support with your order number.';
        else if (/pay|payment/.test(message)) answer = 'Available payment methods are shown during checkout. This demo does not process payments or collect payment details.';
        else if (/track|order/.test(message)) answer = 'You can use the Order Tracking page or your Profile Order History to see orders placed in this browser.';
        else if (/product|shop|price/.test(message)) answer = 'Browse the Products page to see the catalog. Prices and products in this browser-only demo are for preview purposes.';
        else if (/affiliate|influencer|earn|commission/.test(message)) answer = 'Visit Earn With Us or your Affiliate dashboard to manage referral links, promo codes, and commissions.';
        return { answer, source: 'DEMO' };
      }
      throw new Error('This action is not available in the browser-only demo.');
    },
  };

  if (!window.FiadAPI) {
    window.FiadAPI = { api, cart, wishlist, toast, findCatalogProduct, config: { API_BASE: '/api', DEMO: true }, escapeHtml: value => String(value ?? '').replace(/[&<>"']/g, ch => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[ch])) };
  } else {
    window.FiadAPI.cart ||= cart;
    window.FiadAPI.wishlist ||= wishlist;
    window.FiadAPI.api ||= api;
    window.FiadAPI.toast ||= toast;
    window.FiadAPI.findCatalogProduct ||= findCatalogProduct;
    window.FiadAPI.config ||= { API_BASE: '/api', DEMO: true };
    window.FiadAPI.config.DEMO ??= true;
    window.FiadAPI.escapeHtml ||= value => String(value ?? '').replace(/[&<>"']/g, ch => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[ch]));
  }

  async function hashPassword(password) {
    if (!window.crypto?.subtle || typeof TextEncoder === 'undefined') {
      throw new Error('For demo sign-in, open the site on localhost or HTTPS.');
    }
    const digest = await window.crypto.subtle.digest('SHA-256', new TextEncoder().encode(String(password)));
    return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('');
  }
  function notifyAuthChanged() {
    document.dispatchEvent(new CustomEvent('fiad:auth-changed'));
    updateAuthNavigation();
    updateAffiliateLinks();
  }
  function establishSession(account) {
    const email = emailKey(account.email);
    const priorProfile = readJson('fiad_profile', null);
    const matches = priorProfile && emailKey(priorProfile.email) === email;
    const profile = Object.assign({
      name: account.name || email.split('@')[0], email: account.email,
      phone: '', city: '', country: '', zip: '', address: '', address2: '', joined: joinedLabel()
    }, account.profile || {}, matches ? priorProfile : {});
    profile.email = account.email;
    profile.name = profile.name || account.name || email.split('@')[0];
    saveJson('fiad_profile', profile);
    saveJson('fiad_2fa', Boolean(account.twoFactorEnabled));
    const user = { email: account.email, name: profile.name, verified: true };
    saveJson('fiad_user', user);
    safeSet('fiad_token', 'browser-demo-token');
    saveJson('fiad_pending_auth', null);
    return user;
  }

  const auth = {
    getUser,
    getProfile() { return readJson('fiad_profile', {}); },
    isLoggedIn() { return !!getUser(); },
    isAdmin() { return FiadAdminAuth.isLoggedIn(); },
    isAffiliate() { return true; },
    isInfluencer() { return FiadAffiliate.getState().isInfluencer; },
    async login(email, password, twoFactorCode = '') {
      const key = emailKey(email);
      if (!key || !password) throw new Error('Enter your email and password.');
      const accounts = readAccounts();
      const account = accounts[key];
      if (!account) throw new Error('No account found. Please register first.');
      const submittedHash = await hashPassword(password);
      if (submittedHash !== account.passwordHash) throw new Error('Email or password is incorrect.');
      if (account.twoFactorEnabled) {
        const clean2fa = String(twoFactorCode || '').trim();
        if (!clean2fa) {
          return { requiresTwoFactor: true, email: account.email };
        }
        if (clean2fa !== '123456') {
          throw new Error('Incorrect 2FA code. Use demo 2FA code 123456.');
        }
      }
      saveJson('fiad_pending_auth', { email: account.email, flow: 'login' });
      return { requiresOtp: true, email: account.email };
    },
    async register(email, password, displayName = '', referralCode = '') {
      const key = emailKey(email);
      if (!key || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(key)) throw new Error('Enter a valid email address.');
      if (!password || String(password).length < 8) throw new Error('Password must be at least 8 characters.');
      const accounts = readAccounts();
      if (accounts[key]) throw new Error('An account with this email already exists.');
      const name = String(displayName || key.split('@')[0]).trim();
      const cleanRef = String(referralCode || safeGet('fiad_ref', '') || '').trim().toUpperCase();
      if (cleanRef) {
        safeSet('fiad_ref', cleanRef);
        safeSet('fiad_promo', cleanRef);
      }
      const account = {
        email: key,
        name,
        passwordHash: await hashPassword(password),
        verified: false,
        twoFactorEnabled: false,
        referredBy: cleanRef || null,
        createdAt: new Date().toISOString(),
        profile: { name, email: key, phone: '', city: '', country: '', zip: '', address: '', address2: '', joined: joinedLabel() }
      };
      accounts[key] = account;
      saveAccounts(accounts);
      saveJson('fiad_pending_auth', { email: key, flow: 'register' });
      return { ok: true, demo: true, email: key };
    },
    async verifyOtp(email, code) {
      const key = emailKey(email);
      if (String(code || '').trim() !== '1122') throw new Error('Incorrect code. Enter the 4-digit demo code.');
      const pending = readJson('fiad_pending_auth', null);
      if (!pending || emailKey(pending.email) !== key) throw new Error('Please sign in or register again before verifying.');
      const accounts = readAccounts();
      const account = accounts[key];
      if (!account) throw new Error('Account not found. Please register first.');
      account.verified = true;
      accounts[key] = account;
      saveAccounts(accounts);
      const user = establishSession(account);
      notifyAuthChanged();
      return { user, demo: true };
    },
    async resendOtp() { return { ok: true, demo: true, code: '1122' }; },
    async changeEmail(oldEmail, newEmail) {
      const oldKey = emailKey(oldEmail), newKey = emailKey(newEmail);
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newKey)) throw new Error('Enter a valid email address.');
      const accounts = readAccounts();
      if (!accounts[oldKey]) throw new Error('Account not found.');
      if (oldKey !== newKey && accounts[newKey]) throw new Error('That email is already in use.');
      const account = accounts[oldKey];
      delete accounts[oldKey];
      account.email = newKey;
      if (account.profile) account.profile.email = newKey;
      accounts[newKey] = account;
      saveAccounts(accounts);
      const pending = readJson('fiad_pending_auth', null);
      if (pending && emailKey(pending.email) === oldKey) { pending.email = newKey; saveJson('fiad_pending_auth', pending); }
      return { user: getUser(), email: newKey };
    },
    updateProfile(data = {}) {
      const current = getUser();
      if (!current) return null;
      const profile = Object.assign({}, readJson('fiad_profile', {}), data);
      const oldKey = emailKey(current.email);
      const nextEmail = String(profile.email || current.email).trim();
      const nextKey = emailKey(nextEmail);
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(nextKey)) throw new Error('Enter a valid email address.');
      const accounts = readAccounts();
      const account = accounts[oldKey] || Object.assign({ email: nextKey, name: current.name || nextKey.split('@')[0] }, {});
      if (oldKey !== nextKey && accounts[nextKey]) throw new Error('That email is already in use.');
      if (oldKey !== nextKey) delete accounts[oldKey];
      account.email = nextKey;
      account.name = profile.name || current.name || nextKey.split('@')[0];
      account.profile = Object.assign({}, account.profile || {}, profile, { email: nextEmail, name: account.name });
      accounts[nextKey] = account;
      saveAccounts(accounts);
      profile.email = nextEmail;
      profile.name = account.name;
      saveJson('fiad_profile', profile);
      const updatedUser = Object.assign({}, current, { email: nextEmail, name: profile.name });
      saveJson('fiad_user', updatedUser);
      notifyAuthChanged();
      return profile;
    },
    async changePassword(currentPassword, newPassword) {
      const current = getUser();
      if (!current?.email) throw new Error('Please sign in first.');
      const key = emailKey(current.email);
      const accounts = readAccounts();
      const account = accounts[key];
      if (!account) throw new Error('Account record not found.');
      const currentHash = await hashPassword(currentPassword);
      if (currentHash !== account.passwordHash) {
        throw new Error('Current password is incorrect.');
      }
      if (!newPassword || String(newPassword).length < 6) {
        throw new Error('New password must be at least 6 characters.');
      }
      if (currentPassword === newPassword) {
        throw new Error('New password must be different.');
      }
      account.passwordHash = await hashPassword(newPassword);
      accounts[key] = account;
      saveAccounts(accounts);
      return { ok: true };
    },
    setTwoFactor(enabled) {
      const flag = Boolean(enabled);
      saveJson('fiad_2fa', flag);
      const current = getUser();
      if (current?.email) {
        const key = emailKey(current.email);
        const accounts = readAccounts();
        if (accounts[key]) {
          accounts[key].twoFactorEnabled = flag;
          saveAccounts(accounts);
        }
      }
      return flag;
    },
    getTwoFactor() {
      const current = getUser();
      if (current?.email) {
        const account = readAccounts()[emailKey(current.email)];
        if (account && typeof account.twoFactorEnabled === 'boolean') return account.twoFactorEnabled;
      }
      return readJson('fiad_2fa', false) === true;
    },
    deleteAccount() {
      const current = getUser();
      if (!current?.email) throw new Error('Not signed in.');
      const key = emailKey(current.email);
      const accounts = readAccounts();
      delete accounts[key];
      saveAccounts(accounts);
      const remainingOrders = demoOrders().filter(o => emailKey(o.email || o.shippingAddress?.email || '') !== key);
      saveOrders(remainingOrders);
      safeRemove('fiad_profile');
      safeRemove('fiad_2fa');
      safeRemove('fiad_last_order');
      this.logout();
      return { ok: true };
    },
    async forgotPassword(email) {
      const key = emailKey(email);
      if (!key || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(key)) {
        throw new Error('Enter a valid email address.');
      }
      const accounts = readAccounts();
      if (!accounts[key]) {
        throw new Error('No account found with that email address.');
      }
      const token = 'rst_' + Math.random().toString(36).slice(2, 12) + Date.now().toString(36);
      const tokens = readJson('fiad_reset_tokens', {}) || {};
      tokens[token] = {
        email: key,
        createdAt: Date.now(),
        expiresAt: Date.now() + 60 * 60 * 1000,
      };
      saveJson('fiad_reset_tokens', tokens);
      return { ok: true, demo: true, token, email: key };
    },
    async resetPassword(token, newPassword) {
      if (!newPassword || String(newPassword).length < 8) {
        throw new Error('Password must be at least 8 characters.');
      }
      const cleanToken = String(token || '').trim();
      const tokens = readJson('fiad_reset_tokens', {}) || {};
      const entry = tokens[cleanToken];
      if (!entry || !entry.email || (entry.expiresAt && Date.now() > entry.expiresAt)) {
        throw new Error('Reset link is invalid or expired. Request a new password reset.');
      }
      const accounts = readAccounts();
      const account = accounts[entry.email];
      if (!account) {
        throw new Error('Account not found.');
      }
      account.passwordHash = await hashPassword(newPassword);
      accounts[entry.email] = account;
      saveAccounts(accounts);
      delete tokens[cleanToken];
      saveJson('fiad_reset_tokens', tokens);
      return { ok: true, demo: true, email: entry.email };
    },
    async refreshMe() { return getUser(); },
    logout() {
      safeRemove('fiad_user');
      safeRemove('fiad_token');
      safeRemove('fiad_pending_auth');
      notifyAuthChanged();
    },
  };
  window.FiadAuth = auth;

  function updateAffiliateLinks() {
    const state = FiadAffiliate.getState();
    const target = state.isInfluencer ? 'influencer.html' : 'affiliate.html';
    document.querySelectorAll('a[href="affiliate.html"], a[href="influencer.html"], a[data-affiliate-link]').forEach(link => {
      link.setAttribute('href', target);
      if (link.hasAttribute('data-affiliate-profile-link')) {
        const label = link.querySelector('[data-affiliate-label]');
        const icon = link.querySelector('[data-affiliate-icon]');
        if (label) label.textContent = state.isInfluencer ? 'Influencer' : 'Affiliate';
        if (icon) icon.className = (state.isInfluencer ? 'fa-solid fa-crown text-cta-500' : 'fa-solid fa-bullhorn') + ' w-4 text-center';
        link.setAttribute('aria-label', state.isInfluencer ? 'Influencer dashboard' : 'Affiliate dashboard');
      }
    });
  }

  function updateAuthNavigation() {
    const user = getUser();
    const topLink = document.querySelector('[data-auth-top-link]');
    const menuLink = document.querySelector('[data-auth-menu-link]');
    const target = user ? 'profile.html' : 'login.html';
    const label = user ? 'Profile' : 'Login/Register';
    if (topLink) {
      topLink.href = target;
      topLink.setAttribute('aria-label', label);
      topLink.title = label;
    }
    if (menuLink) {
      menuLink.href = target;
      menuLink.setAttribute('aria-label', label);
      const text = menuLink.querySelector('[data-auth-label]');
      if (text) text.textContent = label;
      const icon = menuLink.querySelector('[data-auth-icon]');
      if (icon) icon.className = (user ? 'fa-regular fa-user' : 'fa-solid fa-right-to-bracket') + ' w-4 text-center';
    }
    const welcome = document.getElementById('hero-welcome');
    const guestActions = document.getElementById('hero-guest-actions');
    const signedInGreeting = document.getElementById('hero-user');
    if (welcome) welcome.textContent = `Welcome, ${user?.name?.trim() || user?.email?.split('@')[0] || ''}`;
    if (guestActions) guestActions.classList.toggle('hidden', !!user);
    if (signedInGreeting) signedInGreeting.classList.toggle('hidden', !user);
  }

  document.addEventListener('fiad:auth-changed', updateAuthNavigation);
  document.addEventListener('fiad:affiliate-changed', updateAffiliateLinks);

  function wireSharedControls() {
    applyTheme(preferredTheme, false);
    updateAuthNavigation();
    updateAffiliateLinks();
    const toggle = document.getElementById('site-theme-toggle');
    if (toggle && !toggle.dataset.bound) {
      toggle.dataset.bound = 'true';
      toggle.addEventListener('click', () => {
        preferredTheme = document.documentElement.classList.contains('dark') ? 'light' : 'dark';
        applyTheme(preferredTheme, true);
      });
    }

    const menuButton = document.getElementById('menu-toggle');
    const menu = document.getElementById('quick-menu');
    if (menuButton && menu && !menuButton.dataset.bound) {
      menuButton.dataset.bound = 'true';
      const setOpen = open => {
        menu.classList.toggle('hidden', !open);
        menuButton.setAttribute('aria-expanded', String(open));
        menuButton.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
      };
      menuButton.addEventListener('click', event => {
        event.stopPropagation();
        setOpen(menu.classList.contains('hidden'));
      });
      document.addEventListener('click', event => {
        if (!menu.contains(event.target) && !menuButton.contains(event.target)) setOpen(false);
      });
      document.addEventListener('keydown', event => { if (event.key === 'Escape') setOpen(false); });
    }
    updateBadges();
  }

  document.addEventListener('DOMContentLoaded', wireSharedControls, { once: true });
  if (document.readyState !== 'loading') wireSharedControls();
  document.addEventListener('fiad:cart-updated', updateBadges);
  document.addEventListener('fiad:wishlist-updated', updateBadges);
  window.addEventListener('storage', event => {
    if (event.key === 'theme' || event.key === 'fiad_theme') {
      preferredTheme = event.newValue === 'dark' ? 'dark' : 'light';
      applyTheme(preferredTheme, false);
    }
    if (event.key === 'fiad_cart' || event.key === 'fiad_wishlist') updateBadges();
    if (event.key === 'fiad_user') updateAuthNavigation();
    if (event.key === 'fiad_affiliate_state' || event.key === 'fiad_affiliate_personal_code' || event.key === 'fiad_affiliate_withdrawals' || event.key === 'fiad_orders') {
      updateAffiliateLinks();
      document.dispatchEvent(new CustomEvent('fiad:affiliate-changed', { detail: FiadAffiliate.getState() }));
    }
  });
})();
