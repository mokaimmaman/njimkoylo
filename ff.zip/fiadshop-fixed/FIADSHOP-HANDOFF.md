# FIADSHOP — Handoff for a new chat session

## Project files to use
- The complete current project is in `/home/user/fiadshop-fixed/` in this session. In the new chat, the project files will be supplied individually.
- Preserve the project folder and relative paths when transferring the individual files; pages rely on neighboring scripts, styles, and other local assets.
- Do not assume the new session can access this workspace. Inspect the supplied files and confirm the expected pages/assets are present before editing.

## User’s instruction
Continue from the individually supplied project files and preserve the requirements below. Do not invent functionality, data, successful tests, or backend services. Be explicit when something is a demo/static placeholder or has not been verified.

## Project requirements and decisions to preserve
- Use the supplied shared site header consistently on all pages, except `checkout.html`, which retains its checkout-specific header.
- Headers must not be sticky. Light theme is the default; the user’s chosen theme persists site-wide using localStorage.
- Do not add footers to pages that previously had none. Remove the existing `login.html` footer. Remove the footer’s “Support” item.
- Remove the `$50` free-shipping offer and related promotional messaging.
- Wishlist is in the three-dot menu and must not have a numeric badge.
- Checkout must not preselect a payment method; the user has to choose one.
- Login and registration use fixed demo OTP `1122`. Registration returns to Login, prefills email/password, and exposes OTP verification. This is browser-only demo authentication, not secure/backend auth.
- After login, show Profile instead of Login/Register in the header. On the index page, logged-in users see `Welcome, [Name]`; logged-out users see Shop Now, Earn With Us, and Shop without login—not `Welcome, Guest`.
- Checkout autofills details from the saved profile and saves any changes to profile only when Place Order is clicked.
- Profile theme selection persists site-wide. Country dropdown should retain a saved country, otherwise start blank.
- Use `ai.svg.txt` as the source for AI logo graphics.
- Preserve each page’s language while correcting spelling/grammar.
- Frontend must work without a backend/API. Any auth/OTP behavior is demo-only.
- Product details price is `$110`. Buy Now goes to Checkout without adding to cart; Add to Cart adds the item. On mobile, Wishlist replaces the phone/chat control.
- Deleting one order or all orders requires confirmation.
- Clear all data clears orders, Wishlist, cart, and personal/contact profile details, while preserving account credentials and signed-in state.

## Latest requested changes already applied to the project
- `index.html`: “Shop without login” is an orange underlined link below the guest Shop Now and Earn With Us CTAs. The styling reference was `/home/user/uploads/index.html`.
- `product-detail.html`: Add to Cart was given a visible warm-orange background rather than a near-white tint; the malformed dark-mode selector was fixed; Share and Copy link controls were added. Copy link was browser-tested and displayed “Product link copied.” The displayed price is `$110`.
- `order-confirmation.html`: removed the extra lower logo/header strip; the page has one shared header.
- `profile.html`: added an Affiliate sidebar entry linking to `affiliate.html`.
- `affiliate.html`: created from `/home/user/uploads/affiliate (1).html`, adapted to the shared, non-sticky site header and site-wide theme. It is a frontend dashboard/template and is not connected to a backend.
- `README.md`: updated for the follow-up changes.

## Validation performed (be precise about scope)
- All local file references within the project were found during validation.
- All 21 HTML pages’ inline JavaScript passed `node --check`; `site-common.js` also passed `node --check`.
- Browser checks: index guest CTAs were present; Product Details rendered at mobile width; Copy link showed its success status; a Profile Affiliate link click navigated to `affiliate.html`; Affiliate Dashboard loaded and showed the signed-in demo name. These tested the browser-only frontend flows, not production/backend behavior.
- Browser console showed zero JavaScript/resource errors on the tested pages after adding a data favicon to the Affiliate page. One warning remains from the existing Tailwind CDN setup (known production-use warning).
- Product image content is not supplied in the current product page preview; it displays a placeholder/gallery-space notice. Do not claim an actual product image was added.
- The Profile sidebar has an existing `lg:sticky` positioning class; this is a sidebar, not a sticky header. The stated requirement was no sticky header.

## Relevant original references (if present in the new session)
- `/home/user/uploads/index.html` — reference appearance for “Shop without login”.
- `/home/user/uploads/affiliate (1).html` — Affiliate Dashboard source.
- `/home/user/uploads/product-detail.html` — product detail reference. The current follow-up intentionally makes the Add to Cart background more visibly warm orange in response to the user’s complaint that it looked white.

## Suggested next step in the new session
First confirm that the individually supplied project files are complete and retain their relative paths, then inspect the project before making further edits. If the user only wants the files handed over, do not silently change them.
